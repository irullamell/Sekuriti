const pkg = require("./package.json");
const {
    monospace,
    italic,
    quote
} = require("@mengkodingan/ckptw");

// Bot
config = {
    bot: {
        name: "Clover Bot",
        prefix: /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i,
        phoneNumber: "6285179956361", // Abaikan jika Anda menggunakan kode QR untuk otentikasi
        picture: {
            thumbnail: "https://files.catbox.moe/yqpqbe.jpg",
            profile: "https://i.ibb.co/3Fh9V6p/avatar-contact.png"
        },
        groupChat: "https://chat.whatsapp.com" // Jangan lupa untuk bergabung ya teman-teman!
    },

    // MSG (Pesan)
    msg: {
        // Akses perintah
        admin: quote("❎ Perintah hanya dapat diakses oleh admin grup!"),
        banned: quote("❎ Tidak dapat memproses karena Anda telah dibanned!"),
        botAdmin: quote("❎ Bot bukan admin, tidak bisa menggunakan perintah!"),
        cooldown: quote("❎ Perintah ini sedang dalam cooldown, tunggu..."),
        coin: quote("❎ Anda tidak punya cukup koin!"),
        group: quote("❎ Perintah hanya dapat diakses dalam grup!"),
        owner: quote("❎ Perintah hanya dapat diakses Owner!"),
        premium: quote("❎ Anda bukan pengguna Premium!"),
        private: quote("❎ Perintah hanya dapat diakses dalam obrolan pribadi!"),
        restrict: quote("❎ Perintah ini telah dibatasi karena alasan keamanan!"),

        // Antarmuka perintah
        watermark: `${pkg.name}@^${pkg.version}`,
        footer: italic("Developed by Kaizen"),
        readmore: "\u200E".repeat(4001),

        // Proses perintah
        wait: quote("🔄 Tunggu sebentar..."),
        notFound: quote("❎ Tidak ada yang ditemukan!"),
        urlInvalid: quote("❎ URL tidak valid!")
    },

    // Owner & CoOwner
    owner: {
        name: "Kaizen",
        number: "441135220437",
        organization: "Clover",
        co: ["441135220437"]
    },

    // Stiker
    sticker: {
        packname: "Stiker ini dibuat oleh",
        author: "@Clover Bot"
    },

    // Sistem
    system: {
        autoRead: true,
        autoTypingOnCmd: true,
        cooldown: 5000,
        restrict: true, // Membatasi beberapa perintah yang akan mengakibatkan banned
        selfReply: true,
        timeZone: "Asia/Jakarta",
        usePairingCode: true
    }
};