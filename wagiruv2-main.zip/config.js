global.owner = ['6285646584823']  
global.mods = ['6285646584823'] 
global.prems = ['6285646584823']
global.nameowner = 'Irull'
global.numberowner = '6285646584823' 
global.botname = 'Cloverial'
global.numberbot = "0"
global.mail = 'entot@gmail.com' 
global.gc = 'https://chat.whatsapp.com'
global.instagram = 'https://instagram.com'
global.website = 'https://google.com'
global.wm = 'Cloverial'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With'
global.author = 'Cloverial Bot'
global.autobio = false // Set true untuk mengaktifkan autobio
global.maxwarn = '5' // Peringatan maksimum
global.antiporn = false // Auto delete pesan porno (bot harus admin)

//INI WAJIB DI ISI!//
global.btc = '670cf13b5aabea64c24c' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'JDgbMuvq'
//Daftar https://api.betabotz.eu.org 

global.rose = 'Rk-SarulBelatungPadang123'

global.APIs = {   
  btc: 'https://api.botcahx.eu.org',
  widipe: 'https://widipe.com',
  rose: 'https://api.itsrose.rest'
}
global.APIKeys = { 
  'https://api.botcahx.eu.org': '670cf13b5aabea64c24c' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
