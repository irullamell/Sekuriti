const axios = require('axios');

const tiktokTts = async (text, id) => {
return new Promise(async (resolve, reject) => {
axios("https://tiktok-tts.weilnet.workers.dev/api/generation", {
headers: {
"Content-Type": "application/json",
"User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
},
data: {
text: text,
voice: id
},
method: "POST"
}).then(a => {
resolve(a.data.data);
}).catch(error => {
reject(error);
});
});
};

const voices = [
// Disney voices
"en_us_ghostface", // Ghost Face
"en_us_chewbacca", // Chewbacca
"en_us_c3po", // C3PO
"en_us_stitch", // Stitch
"en_us_stormtrooper", // Stormtrooper
"en_us_rocket", // Rocket

// English voices
"en_au_001", // English AU - Female
"en_au_002", // English AU - Male
"en_uk_001", // English UK - Male 1
"en_uk_003", // English UK - Male 2
"en_us_001", // English US - Female (Int. 1)
"en_us_002", // English US - Female (Int. 2)
"en_us_006", // English US - Male 1
"en_us_007", // English US - Male 2
"en_us_009", // English US - Male 3
"en_us_010", // English US - Male 4

// Europe voices
"fr_001", // French - Male 1
"fr_002", // French - Male 2
"de_001", // German - Female
"de_002", // German - Male
"es_002", // Spanish - Male

// America voices
"es_mx_002", // Spanish MX - Male
"br_001", // Portuguese BR - Female 1
"br_003", // Portuguese BR - Female 2
"br_004", // Portuguese BR - Female 3
"br_005", // Portuguese BR - Male

// Asia voices
"id_001", // Indonesian - Female
"jp_001", // Japanese - Female 1
"jp_003", // Japanese - Female 2
"jp_005", // Japanese - Female 3
"jp_006", // Japanese - Male
"kr_002", // Korean - Male 1
"kr_003", // Korean - Female
"kr_004", // Korean - Male 2

// Singing voices
"en_female_f08_salut_damour", // Alto
"en_male_m03_lobby", // Tenor
"en_female_f08_warmy_breeze", // Warmy Breeze
"en_male_m03_sunshine_soon", // Sunshine Soon

// Other
"en_male_narration", // narrator
"en_male_funny", // wacky
"en_female_emotional", // peaceful
]

exports.run = {
usage: ['tiktts2'],
use: 'text',
category: 'convert',
async: async (m, { func, mecha, errorMessage }) => {
let text
if (m.args.length >= 1) {
text = m.args.slice(0).join(' ')
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text
} else return m.reply('Input atau reply text!')
if (!text) return m.reply(func.example(m.cmd, 'aku sayang kamu'))
if (func.isNumber(text)) return m.reply('Teks harus berupa huruf.')
let model = func.pickRandom(voices)
m.reply(`_Get random model: ${model}_`)
await tiktokTts(text, model).then(async (result) => {
await mecha.sendMessage(m.chat, {
audio: Buffer.from(result, 'base64'), 
mimetype: 'audio/mp4', ptt: true
}, {quoted: m, ephemeralExpiration: m.expiration})
}).catch((e) => {
m.reply(global.mess.error.api)
return errorMessage(e)
})
},
limit: 3,
restrict: true
}