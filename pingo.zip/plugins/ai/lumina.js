const axios = require('axios');

async function luminaAi(q) {
try {
const response = await axios.post('https://ai.sanzy.co/api/chat', { text: q }, {
headers: {
'Content-Type': 'application/json',
}
});

let result = '';
const req = response.data.split('data: ').slice(1);
req.forEach(response => {
const tobrut = response.trim();
if (tobrut) {
try {
const content = JSON.parse(tobrut).content;
result += content;
} catch (e) {
return null;
}
}
});

return result.trim(); 
} catch (error) {
console.error('Error fetching data:', error);
throw error; 
}
}

exports.run = {
usage: ['aira'],
hidden: ['airaai', 'sanzy', 'lumina'],
use: 'question',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'hai'))
mecha.sendReact(m.chat, '🕒', m.key)
try {
let messageId = 'BAE5' + func.makeid(6).toUpperCase() + 'LUMINA'
let response = await luminaAi(m.text);
await mecha.sendMessage(m.chat, {
text: `${response}`,
},
{
quoted: m, 
ephemeralExpiration: m.expiration,
messageId: messageId
});
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key)
return errorMessage(error)
}
},
main: async (m, { func, mecha, errorMessage }) => {
if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('LUMINA') && !m.isPrefix) {
mecha.sendReact(m.chat, '🕒', m.key)
try {
let messageId = 'BAE5' + func.makeid(6).toUpperCase() + 'LUMINA'
let response = await luminaAi(m.budy);
mecha.sendMessage(m.chat, {
text: `${response}`
}, {
quoted: m,
ephemeralExpiration: m.expiration,
messageId: messageId
});
global.db.users[m.sender].limit -= 1
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key)
return errorMessage(error)
}
}
},
limit: true
}