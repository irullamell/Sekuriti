exports.run = {
usage: ['hidetag'],
hidden: ['h'],
use: 'text',
category: 'group',
async: async (m, { func, mecha }) => {
mecha.sendMessage(m.chat, {
text: m.text ? m.text : m.quoted ? m.quoted.text : '',
mentions: m.members.map(x => x.id)
}, {quoted: func.fverified, ephemeralExpiration: m.expiration})
},
group: true,
admin: true
}