const axios = require('axios');
const cheerio = require('cheerio');

async function ssweb(url, device = 'desktop') {
return new Promise((resolve, reject) => {
const base = 'https://www.screenshotmachine.com'
const param = {
url: url,
device: device,
cacheLimit: 0
}
axios({
url: base + '/capture.php',
method: 'POST',
data: new URLSearchParams(Object.entries(param)),
headers: {
'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
}
})
.then((data) => {
const cookies = data.headers['set-cookie']
if (data.data.status == 'success') {
axios.get(base + '/' + data.data.link, {
headers: {
'cookie': cookies.join('')
},
responseType: 'arraybuffer'
})
.then(({ data }) => {
const result = {
status: true,
result: data
}
resolve(result)
})
} else {
reject({
status: false,
message: data.data
})
}
})
.catch (reject)
})
}

exports.run = {
usage: ['ssweb'],
use: 'url',
category: 'tools',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply('Masukkan URL nya.')
if (!func.isUrl(m.args[0])) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
await ssweb(m.text).then(res => {
if (!res.status) return m.reply(global.mess.error.api)
mecha.sendMessage(m.chat, {image: res.result, caption: global.mess.ok}, {quoted: m, ephemeralExpiration: m.expiration})
})
},
limit: 3
}