const items = {
  buy: {
    potion: { balance: 1250 },
    wood: { balance: 2000 },
    aqua: { balance: 1000 },
    rock: { balance: 2000 },
    string: { balance: 2500 },
    iron: { balance: 3000 },
    sand: { balance: 1500 },
    emerald: { balance: 200000 },
    diamond: { balance: 300000 },
    gold: { balance: 100000 },
    petfood: { balance: 2500 },
    bawang: { balance: 150 },
    cabai: { balance: 250 },
    kemiri: { balance: 100 },
    jahe: { balance: 100 },
    saus: { balance: 70 },
    asam: { balance: 50 },
    bibitapel: { balance: 150 },
    bibitanggur: { balance: 200 },
    bibitmangga: { balance: 250 },
    bibitpisang: { balance: 50 },
    bibitjeruk: { balance: 300 },
    common: { balance: 10000 },
    uncommon: { balance: 15000 },
    mythic: { balance: 25000 },
    legendary: { balance: 40000 },
    banteng: { balance: 11000 },
    harimau: { balance: 18000 },
    gajah: { balance: 16000 },
    kambing: { balance: 12000 },
    panda: { balance: 20000 },
    buaya: { balance: 5000 },
    kerbau: { balance: 9000 },
    sapi: { balance: 10000 },
    monyet: { balance: 5000 },
    babihutan: { balance: 4000 },
    babi: { balance: 8000 },
    ayam: { balance: 3000 },
    orca: { balance: 20000 },
    paus: { balance: 45000 },
    lumba: { balance: 5000 },
    hiu: { balance: 4500 },
    ikan: { balance: 2500 },
    lele: { balance: 3000 },
    bawal: { balance: 3500 },
    nila: { balance: 3000 },
    kepiting: { balance: 7000 },
    lobster: { balance: 15000 },
    gurita: { balance: 3000 },
    cumi: { balance: 5000 },
    udang: { balance: 7500 },
    horse: { balance: 500000 },
    cat: { balance: 500000 },
    fox: { balance: 500000 },
    dog: { balance: 500000 },
    wolf: { balance: 1000000 },
    centaur: { balance: 15 },
    phoenix: { balance: 10 },
    dragon: { balance: 10 },
    rumahsakit: { balance: 2000000 },
    restoran: { balance: 2500000 },
    pabrik: { balance: 1000000 },
    tambang: { balance: 2000000 },
    pelabuhan: { balance: 2500000 }
  },
  sell: {
    potion: { balance: 875 }, // 70% of 1250
    petfood: { balance: 1750 }, // 70% of 2500
    trash: { balance: 14 }, // 70% of 20
    botol: { balance: 35 }, // 70% of 50
    kaleng: { balance: 105 }, // 70% of 150
    kardus: { balance: 70 }, // 70% of 100
    banteng: { balance: 7700 }, // 70% of 11000
    harimau: { balance: 12600 }, // 70% of 18000
    gajah: { balance: 11200 }, // 70% of 16000
    kambing: { balance: 8400 }, // 70% of 12000
    panda: { balance: 14000 }, // 70% of 20000
    buaya: { balance: 3500 }, // 70% of 5000
    kerbau: { balance: 6300 }, // 70% of 9000
    sapi: { balance: 7000 }, // 70% of 10000
    monyet: { balance: 3500 }, // 70% of 5000
    babihutan: { balance: 2800 }, // 70% of 4000
    babi: { balance: 5600 }, // 70% of 8000
    ayam: { balance: 2100 }, // 70% of 3000
    orca: { balance: 14000 }, // 70% of 20000
    paus: { balance: 31500 }, // 70% of 45000
    lumba: { balance: 3500 }, // 70% of 5000
    hiu: { balance: 3150 }, // 70% of 4500
    ikan: { balance: 1750 }, // 70% of 2500
    lele: { balance: 2100 }, // 70% of 3000
    bawal: { balance: 2450 }, // 70% of 3500
    nila: { balance: 2100 }, // 70% of 3000
    kepiting: { balance: 4900 }, // 70% of 7000
    lobster: { balance: 10500 }, // 70% of 15000
    gurita: { balance: 2100 }, // 70% of 3000
    cumi: { balance: 3500 }, // 70% of 5000
    udang: { balance: 5250 }, // 70% of 7500
    mangga: { balance: 280 }, // 70% of 400
    anggur: { balance: 210 }, // 70% of 300
    jeruk: { balance: 315 }, // 70% of 450
    pisang: { balance: 140 }, // 70% of 200
    apel: { balance: 210 }, // 70% of 300
    steak: { balance: 24500 }, // 70% of 35000
    sate: { balance: 25200 }, // 70% of 36000
    rendang: { balance: 17360 }, // 70% of 24800
    kornet: { balance: 15120 }, // 70% of 21600
    nugget: { balance: 17920 }, // 70% of 25600
    bluefin: { balance: 36400 }, // 70% of 52000
    seafood: { balance: 36400 }, // 70% of 52000
    sushi: { balance: 30520 }, // 70% of 43600
    moluska: { balance: 36400 }, // 70% of 52000
    squidprawm: { balance: 33880 }, // 70% of 48400
    horse: { balance: 350000 }, // 70% of 500000
    cat: { balance: 350000 }, // 70% of 500000
    fox: { balance: 350000 }, // 70% of 500000
    dog: { balance: 350000 }, // 70% of 500000
    wolf: { balance: 700000 }, // 70% of 1000000
    centaur: { balance: 1050000 }, // 70% of 1500000
    phoenix: { balance: 1260000 }, // 70% of 1800000
    dragon: { balance: 1890000 }, // 70% of 2700000
    rumahsakit: { balance: 1400000 }, // 70% of 2000000
    restoran: { balance: 1750000 }, // 70% of 2500000
    pabrik: { balance: 700000 }, // 70% of 1000000
    tambang: { balance: 1400000 }, // 70% of 2000000
    pelabuhan: { balance: 1750000 } // 70% of 2500000
}
}
}

exports.run = {
usage: ['buy', 'sell'],
hidden: ['beli', 'shop', 'jual'],
use: '[item] [count]',
category: 'rpg',
async: async (m, { func, mecha, isPrem }) => {
let user = global.db.users[m.sender]
const listItems = Object.fromEntries(Object.entries(items[`${func.somematch(['buy', 'shop', 'beli'], m.command) ? 'buy' : 'sell'}`]).filter(([v]) => v && v in user))
let info = `Format : *${m.cmd} [item] [jumlah]*
Contoh : *${m.cmd} potion 10*

*D A I L Y - I T E M S*
%| potion%
%| aqua%
%| petfood%

*C R A F T - I T E M S*
%| wood | rock%
%| string | iron%
%| sand | emerald%
%| diamond | gold%

*COOKING - INGREDIENTS*${func.readmore}
%| bawang | cabai%
%| kemiri | jahe%
%| saus | asam%

*GARDENING - MATERIALS*
%| bibitmangga%
%| bibitapel%
%| bibitpisang%
%| bibitjeruk%
%| bibitanggur%

*G A C H A - B O X*
%| common%
%| uncommon%
%| mythic%
%| legendary%

*L A N D - A N I M A L S*
%| banteng | harimau%
%| gajah | kambing%
%| panda | buaya%
%| kerbau | sapi%
%| monyet | babihutan%
%| babi | ayam%

*S E A - A N I M A L S*
%| orca | paus%
%| lumba | hiu%
%| ikan | lele%
%| bawal | nila%
%| kepiting | lobster%
%| gurita | cumi%
%| udang%

*P E T - S H O P*
%| horse | cat%
%| fox | dog%
%| wolf | centaur%
%| phoenix | dragon%

*B U I L D I N G S*
%| rumahsakit%
%| estoran%
%| pabrik%
%| tambang%
%| pelabuhan%`

let infos = `Format : *${m.cmd} [item] [jumlah]*
Contoh : *${m.cmd} potion 10*

*D A I L Y - I T E M S*
%| potion%
%| petfood%
%| trash%

*S E L L - A N I M A L S*
%| banteng | harimau%
%| gajah | kambing%
%| panda | buaya%
%| kerbau | sapi%
%| monyet | babihutan%
%| babi | ayam%

*S E A - A N I M A L S*${func.readmore}
%| orca | paus%
%| lumba | hiu%
%| ikan | lele%
%| bawal | nila%
%| kepiting | lobster%
%| gurita | cumi%
%| udang%

*S E L L - F R U I T S*
%| mangga%
%| anggur%
%| jeruk%
%| pisang%
%| apel%

*P E T - S E L L*
%| horse | cat%
%| fox | dog%
%| wolf | centaur%
%| phoenix | dragon%

*B U I L D I N G S*
%| rumahsakit%
%| estoran%
%| pabrik%
%| tambang%
%| pelabuhan%`

const item = (m.args[0] || '').toLowerCase()
const total = Math.floor(func.isNumber(m.args[1]) ? Math.min(Math.max(parseInt(m.args[1]), 1), Number.MAX_SAFE_INTEGER) : 1) * 1
if (func.somematch(['sell', 'jual'], m.command) && m.text.toLowerCase() === 'hewan darat') {
let itemArray = ['banteng', 'harimau', 'gajah', 'kambing', 'panda', 'buaya', 'kerbau', 'sapi', 'monyet', 'babihutan', 'babi', 'ayam']
let totalItem = 0;
let totalHarga = 0;
for (let x of itemArray) totalItem += parseInt(user[x]);
if (totalItem == 0) return m.reply(`Kamu tidak memiliki *${m.text.toLowerCase()}* untuk dijual.`)
for (let i of itemArray) {
let count = parseInt(user[i])
user[i] -= count;
user.balance += listItems[i].balance * count;
totalHarga += listItems[i].balance * count;
}
return m.reply(`Menjual *${totalItem} ${m.text.toLowerCase()}* dengan harga *${totalHarga} balance*`)
} else if (func.somematch(['sell', 'jual'], m.command) && m.text.toLowerCase() === 'hewan laut') {
let itemArray = ['orca', 'paus', 'lumba', 'hiu', 'ikan', 'lele', 'bawal', 'nila', 'kepiting', 'lobster', 'gurita', 'cumi', 'udang']
let totalItem = 0;
let totalHarga = 0;
for (let x of itemArray) totalItem += parseInt(user[x]);
if (totalItem == 0) return m.reply(`Kamu tidak memiliki *${m.text.toLowerCase()}* untuk dijual.`)
for (let i of itemArray) {
let count = parseInt(user[i])
user[i] -= count;
user.balance += listItems[i].balance * count;
totalHarga += listItems[i].balance * count;
}
return m.reply(`Menjual *${totalItem} ${m.text.toLowerCase()}* dengan harga *${totalHarga} balance*`)
} else if (func.somematch(['sell', 'jual'], m.command) && m.text.toLowerCase() === 'buah') {
let itemArray = ['mangga', 'anggur', 'jeruk', 'pisang', 'apel']
let totalItem = 0;
let totalHarga = 0;
for (let x of itemArray) totalItem += parseInt(user[x]);
if (totalItem == 0) return m.reply(`Kamu tidak memiliki *${m.text.toLowerCase()}* untuk dijual.`)
for (let i of itemArray) {
let count = parseInt(user[i])
user[i] -= count;
user.balance += listItems[i].balance * count;
totalHarga += listItems[i].balance * count;
}
return m.reply(`Menjual *${totalItem} ${m.text.toLowerCase()}* dengan harga *${totalHarga} balance*`)
}
if (!listItems[item] && func.somematch(['buy', 'shop', 'beli'], m.command)) return m.reply(info.replaceAll('%', '```'))
if (!listItems[item] && func.somematch(['sell', 'jual'], m.command)) return m.reply(infos.replaceAll('%', '```'))
let paymentMethod = Object.keys(listItems[item]).find(v => v in user)
if (func.somematch(['buy', 'shop', 'beli'], m.command)) {
if (func.somematch(['horse', 'cat', 'fox', 'dog', 'wolf', 'centaur', 'phoenix', 'dragon', 'rumahsakit', 'restoran', 'pabrik', 'tambang', 'pelabuhan'], m.args[0].toLowerCase())) {
if (user[item] == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *${item}*, hanya dapat beli 1`)
if (user[paymentMethod] < listItems[item][paymentMethod] * total) return m.reply(`Kamu tidak memiliki cukup ${paymentMethod} untuk membeli *${total} ${item}*.\nDibutuhkan *${(listItems[item][paymentMethod] * total) - user[paymentMethod]} ${paymentMethod}* untuk dapat membeli.`)
user[paymentMethod] -= listItems[item][paymentMethod] * total
user[item] += total
user[`${item}lvl`] += 1
return m.reply(`Membeli *${total} ${item}* seharga *${listItems[item][paymentMethod] * total} ${paymentMethod}*`)
} else {
let itemlvl = user[`${item}lvl`];
if (user[`${item}`] + total > 2 * itemlvl) return m.reply(`Perlu upgrade ${item} ke level ${2 * itemlvl} terlebih dahulu.`)
let harga = listItems[item][paymentMethod] * total * user[`${item}`] * itemlvl
if (user[paymentMethod] < listItems[item][paymentMethod] * total) return m.reply(`Kamu tidak memiliki cukup ${paymentMethod} untuk membeli *${total} ${item} level ${itemlvl}*.\nDibutuhkan *${(listItems[item][paymentMethod] * total) - user[paymentMethod]} ${paymentMethod}* untuk dapat membeli.`)
user[paymentMethod] -= harga
user[item] += total
return m.reply(`Membeli *${total} ${item}* seharga *${harga} ${paymentMethod}*`)
}
} else {
if (user[paymentMethod] < listItems[item][paymentMethod] * total) return m.reply(`Kamu tidak memiliki cukup ${paymentMethod} untuk membeli *${total}* ${item}.\nDibutuhkan *${(listItems[item][paymentMethod] * total) - user[paymentMethod]} ${paymentMethod}* untuk dapat membeli.`)
user[paymentMethod] -= listItems[item][paymentMethod] * total
user[item] += total
return m.reply(`Membeli *${total} ${item}* seharga *${listItems[item][paymentMethod] * total} ${paymentMethod}*`)
}
} else {
if (func.somematch(['horse', 'cat', 'fox', 'dog', 'wolf', 'centaur', 'phoenix', 'dragon', 'rumahsakit', 'restoran', 'pabrik', 'tambang', 'pelabuhan'], m.args[0].toLowerCase())) {
let itemlvl = user[`${item}lvl`];
let harga = listItems[item][paymentMethod] * total * itemlvl
if (user[item] == 0) return m.reply(`Kamu tidak memiliki *${item}* untuk dijual.`)
if (user[item] < total) return m.reply(`Kamu hanya memiliki *${user[item]} ${item}* untuk dijual.`)
user[item] -= total
user.balance += harga
let meh = user[`${item}lvl`]
if (user[item] == 0) user[`${item}lvl`] = 0
return m.reply(`Menjual *${total} ${item} Level ${meh}* dengan harga *${harga} ${paymentMethod}*`)
} else {
if (user[item] == 0) return m.reply(`Kamu tidak memiliki *${item}* untuk dijual.`)
if (user[item] < total) return m.reply(`Kamu hanya memiliki *${user[item]} ${item}* untuk dijual.`)
user[item] -= total
user.balance += listItems[item].balance * total
return m.reply(`Menjual *${total} ${item}* dengan harga *${listItems[item].balance * total} ${paymentMethod}*`)
}
}
},
register: true
}