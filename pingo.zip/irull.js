const { spawn } = require('child_process');

// Fungsi untuk menjalankan perintah startup
function runCommand(commandString) {
  // Memisahkan command dan argumen dari string input
  const [command, ...args] = commandString.split(' ');

  // Menjalankan perintah dengan argumennya
  spawn(command, args, {
    stdio: ['inherit', 'inherit', 'inherit', 'ipc']
  });
}

// Variabel yang dapat dengan mudah diedit
const startupCommand = 'npm start';  // Ubah command sesuai kebutuhan

// Menjalankan perintah startup
runCommand(startupCommand);
