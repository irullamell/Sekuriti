const cluster = require('cluster');
const path = require('path');
const fs = require('fs');
const package = require('./package.json'); // Placeholder jika dibutuhkan
const CFonts = require('cfonts');
const Readline = require('readline');
const yargs = require('yargs/yargs');

// Inisialisasi interface CLI
const readline = Readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: '> '
});

let isRunning = false;
const MAX_RESTART_ATTEMPTS = 5; // Batas jumlah restart untuk mencegah siklus tak terbatas
let restartAttempts = 0;

/**
 * Menampilkan banner dengan CFonts
 */
function displayBanner() {
    CFonts.say('POWER', {
        font: 'tiny',
        align: 'center',
        colors: ['system']
    });
}

/**
 * Memulai sebuah file JavaScript
 * @param {String} file - Path ke file JS yang akan dijalankan
 */
function start(file) {
    if (isRunning) return; // Cegah menjalankan multiple instances
    isRunning = true;

    const args = [path.join(__dirname, file), ...process.argv.slice(2)];

    // Setup cluster
    cluster.setupMaster({
        exec: path.join(__dirname, file),
        args: args.slice(1),
    });

    // Fork worker baru
    const worker = cluster.fork();

    // Tangani pesan dari worker
    worker.on('message', data => {
        console.log('[ RECEIVED ]', data);
        handleWorkerMessage(data, file, worker);
    });

    // Tangani ketika worker keluar
    worker.on('exit', (code) => {
        isRunning = false;
        console.error(`Worker exited with code: ${code}`);

        if (code !== 0 && restartAttempts < MAX_RESTART_ATTEMPTS) {
            restartAttempts++;
            console.log(`Restarting (${restartAttempts}/${MAX_RESTART_ATTEMPTS})...`);

            // Watch file untuk restart jika file berubah
            fs.watchFile(args[0], (curr, prev) => {
                if (curr.mtime !== prev.mtime) {
                    fs.unwatchFile(args[0]);
                    start(file); // Restart file
                }
            });
        } else if (restartAttempts >= MAX_RESTART_ATTEMPTS) {
            console.error('Max restart attempts reached. Not restarting.');
        }
    });

    setupCommandLineInput(worker);
}

/**
 * Tangani pesan yang diterima dari worker
 * @param {String} data - Data yang dikirim oleh worker
 * @param {String} file - Path file untuk restart jika diperlukan
 * @param {Object} worker - Objek worker dari cluster
 */
function handleWorkerMessage(data, file, worker) {
    switch (data) {
        case 'reset':
            worker.process.kill();  // Hentikan worker
            isRunning = false;      // Set flag ulang
            restartAttempts = 0;    // Reset counter restart
            start(file);            // Restart proses
            break;
        case 'uptime':
            worker.send(process.uptime());  // Kirim uptime ke worker
            break;
        default:
            console.warn('Unknown message from worker:', data);
    }
}

/**
 * Setup input command-line dari pengguna
 * @param {Object} worker - Proses worker untuk berinteraksi
 */
function setupCommandLineInput(worker) {
    const opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());

    // Hanya setup readline jika belum ada listener
    if (!readline.listenerCount('line')) {
        readline.prompt();
        readline.on('line', (line) => {
            const input = line.trim();
            if (input) {
                worker.send(input);  // Kirim input ke worker
            }
            readline.prompt();
        });
    }
}

// Jalankan program utama
displayBanner();
start('main.js');

