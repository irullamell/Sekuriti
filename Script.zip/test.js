const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { spawn } = require('child_process');
const os = require('os');

const config = {
    maxConcurrency: 5, // Batas maksimal proses paralel
    logFile: path.join(__dirname, 'check.log'), // File log
    folders: ['.', ...Object.keys(require('./package.json').directories)], // Folder yang akan diproses
    fileFilter: '.js', // Filter file berdasarkan ekstensi
    excludeFiles: [__filename], // Daftar file yang dikecualikan
};

// Utility untuk logging
function logToFile(message) {
    fs.appendFileSync(config.logFile, `${new Date().toISOString()} - ${message}\n`);
}

// Mendapatkan semua file dengan ekstensi yang diinginkan dari folder
function getAllFiles(folders, extension) {
    const files = [];
    for (const folder of folders) {
        for (const file of fs.readdirSync(folder).filter(v => v.endsWith(extension))) {
            files.push(path.resolve(path.join(folder, file)));
        }
    }
    return files;
}

// Proses file dengan spawn child process
function processFile(file, callback) {
    if (config.excludeFiles.includes(file)) return;

    console.error('Checking', file);
    const proc = spawn(process.argv0, ['-c', file]);

    proc.stderr.on('data', chunk => {
        assert.ok(chunk.length < 1, `${file}\n\nError: ${chunk}`);
        logToFile(`Error found in ${file} - ${chunk}`);
    });

    proc.on('close', (code) => {
        assert.strictEqual(code, 0, `Process exited with code ${code} for ${file}`);
        console.log('Done', file);
        logToFile(`Successfully checked ${file}`);
        if (callback) callback();
    });
}

// Fungsi untuk membatasi concurrency
function processFilesWithLimit(files, limit) {
    let index = 0;
    let running = 0;

    function next() {
        if (index === files.length && running === 0) {
            console.log('All files processed.');
            return;
        }

        while (running < limit && index < files.length) {
            running++;
            processFile(files[index++], () => {
                running--;
                next();
            });
        }
    }

    next();
}

// Main function
function main() {
    logToFile('Starting file check...');
    const files = getAllFiles(config.folders, config.fileFilter);
    const cpuCount = os.cpus().length;
    const concurrencyLimit = Math.min(config.maxConcurrency, cpuCount);

    processFilesWithLimit(files, concurrencyLimit);
}

main();
