module.exports = {
  run: async (m, { conn, Func }) => {
    // Retrieve all users and ensure default values for wins
    const users = Object.entries(global.db.data.users).map(([key, user]) => ({
      id: key,
      winsusunkata: user.winsusunkata || 0,
      wintebakkata: user.wintebakkata || 0,
      winsiapakahaku: user.winsiapakahaku || 0,
      wintebakbendera: user.wintebakbendera || 0,
      wintebakgambar: user.wintebakgambar || 0,
      wintekateki: user.wintekateki || 0,
      winlengkapikalimat: user.winlengkapikalimat || 0
    }));

    // Function to create a leaderboard for a specific game
    const createLeaderboard = (gameKey, gameName, topN = 10) => {
      // Filter out users with zero wins for the specific game
      const filteredUsers = users.filter(user => user[gameKey] > 0);
      
      // Sort filtered users by the specific game's wins in descending order
      const sortedUsers = filteredUsers.sort((a, b) => b[gameKey] - a[gameKey]);
      
      // Prepare leaderboard message
      let leaderboardMessage = `*Leaderboard for ${gameName}*:\n`;

      if (sortedUsers.length === 0) {
        leaderboardMessage += `No players have wins in this game yet.\n`;
      } else {
        for (let i = 0; i < Math.min(sortedUsers.length, topN); i++) { // Display top N users
          const user = sortedUsers[i];
          leaderboardMessage += `*${i + 1}.* @${user.id.split('@')[0]} - *Wins:* [ *${Func.formatNumber(user[gameKey])}* ]\n`;
        }
      }
      
      return leaderboardMessage;
    };

    // Create leaderboards for each game type
    const leaderboards = [
      createLeaderboard('winsusunkata', 'Susunkata'),
      createLeaderboard('wintebakkata', 'Tebak Kata'),
      createLeaderboard('winsiapakahaku', 'Siapakah Aku'),
      createLeaderboard('wintebakbendera', 'Tebak Bendera'),
      createLeaderboard('wintebakgambar', 'Tebak Gambar'),
      createLeaderboard('wintekateki', 'Teka Teki'),
      createLeaderboard('winlengkapikalimat', 'Lengkapi Kalimat')
    ];

    // Send all leaderboards as a single message
    const finalMessage = leaderboards.join('\n\n') + `\n> Terus bermain untuk meningkatkan posisi kamu!`;

    // Handle potential errors and send the message
    try {
      await conn.reply(m.chat, finalMessage, m);
    } catch (error) {
      console.error("Error sending leaderboard message:", error);
      conn.reply(m.chat, "❌ Terjadi kesalahan saat mengirim leaderboard.", m);
    }
  },
  help: ['topwin'],
  tags: ['user'],
  command: /^(topwin)$/i
}