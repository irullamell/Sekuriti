const similarity = require('similarity');
const threshold = 0.72;

module.exports = {
   async before(m, { conn, users, Func }) {
      const chatId = m.chat;
      conn.susunkata = conn.susunkata || {};

      // Check if the message is a response to a valid quote
      if (m.quoted && m.quoted.sender !== conn.decodeJid(conn.user.jid)) return;

      if (m.quoted && /suska untuk bantuan/i.test(m.quoted.text)) {
         // Check if the question has ended
         if (!(chatId in conn.susunkata)) {
            return m.reply('Soal itu telah berakhir');
         }

         const currentQuestion = conn.susunkata[chatId];
         
         if (m.quoted.id === currentQuestion[0].id) {
            // Handle timeout or empty response
            if (['Timeout', ''].includes(m.text)) return true;

            const answerData = JSON.parse(JSON.stringify(currentQuestion[1]));
            const userAnswer = m.text.toLowerCase().trim();

            if (userAnswer === answerData.jawaban.toLowerCase()) {
               // Correct answer
               const totalReward = currentQuestion[2]; // Total reward value
               const expReward = Math.floor(totalReward * 0.5); // 50% of total as EXP
               const moneyReward = totalReward - expReward; // Remaining 50% as Money

               // Randomly choose to send either EXP or Money
               const isExp = Math.random() < 0.5; // 50% chance to give EXP
               
               // Construct the reply message
               let replyMessage = `*Benar!* `;
               replyMessage += `*+ ${Func.formatNumber(expReward)} Exp* `;
               replyMessage += `*dan* *+ ${Func.formatNumber(moneyReward)} Money*`;

               // Update user rewards based on the selection
               if (isExp) {
                  users.exp = (users.exp || 0) + expReward; // Add EXP
               } else {
                  users.money = (users.money || 0) + moneyReward; // Add Money
               }

               await m.reply(replyMessage); // Send combined reply
               users.winsusunkata += 1;
               users.wrongans = 0; // Reset wrong answer count on a correct response
               clearTimeout(currentQuestion[3]);
               delete conn.susunkata[chatId];
            } else if (similarity(userAnswer, answerData.jawaban.toLowerCase()) >= threshold) {
               // Close answer
               m.reply(`*Dikit Lagi!*`);
            } else {
               // Incorrect answer
               users.wrongans = (users.wrongans || 0) + 1; // Increment wrong answer counter
               const penalty = users.wrongans * 5; // Penalty increases by 5 for each wrong answer
               users.exp -= penalty; // Deduct exp
               m.reply(`*Salah!* Kamu kehilangan ${penalty} Exp.`);
            }
         }
      }
      return true;
   }
}