module.exports = {
  run: async (m, { conn, usedPrefix, command, args, users, Func }) => {
    try {
      let price = 35000;
      let count = command.replace(/^buy/i, '');
      count = count ? /all/i.test(count) ? Math.floor(users.exp / price) : parseInt(count) : args[0] ? parseInt(args[0]) : 1;
      count = Math.max(1, count);

      // Calculate total cost
      const totalCost = price * count;

      // Check if the user has enough exp to buy the requested limit
      if (users.exp < totalCost) {
        return conn.reply(m.chat, Func.texted('bold', `Your exp is not enough to buy ${count} limit. You need ${Func.formatNumber(totalCost)} Exp.`), m);
      }

      // Proceed with the purchase
      users.exp -= totalCost;
      users.limit += count;
      conn.reply(m.chat, Func.texted('bold', `-${Func.formatNumber(totalCost)} Exp, +${count} Limit`), m);
    } catch (e) {
      console.log(e);
      return conn.reply(m.chat, Func.jsonFormat(e), m);
    }
  },
  help: ['buy'],
  use: 'amount',
  tags: ['user'],
  command: /^buy([0-9]+)|buy|buyall$/i
}