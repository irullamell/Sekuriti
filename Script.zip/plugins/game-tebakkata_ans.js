const similarity = require('similarity');
const threshold = 0.72;

module.exports = {
   async before(m, { conn, users, Func }) {
      let id = m.chat;
      conn.tebakkata = conn.tebakkata ? conn.tebakkata : {};
      
      // Handle user responses
      if (m.quoted && m.quoted.sender != conn.decodeJid(conn.user.jid)) return;

      if (m.quoted && /teka untuk bantuan/i.test(m.quoted.text)) {
         if (!(id in conn.tebakkata) && /teka untuk bantuan/i.test(m.quoted.text)) return m.reply('Soal itu telah berakhir');
         
         if (m.quoted.id == conn.tebakkata[id][0].id) {
            if (['Timeout', ''].includes(m.text)) return !0;

            let json = JSON.parse(JSON.stringify(conn.tebakkata[id][1]));
            if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
               // Correct answer
               await m.reply(`*Benar*, *+ ${Func.formatNumber(conn.tebakkata[id][2])} Exp*`).then(() => {
                  users.exp += conn.tebakkata[id][2];
                  users.wintebakkata += 1;
                  clearTimeout(conn.tebakkata[id][3]);
                  delete conn.tebakkata[id];
               });
            } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
               // Close answer
               m.reply(`*Dikit Lagi!*`);
            } else {
               // Incorrect answer
               m.reply(`*Salah!*`);
               users.wrongans = (users.wrongans || 0) + 1; // Increment wrong answer count
            }
         }
      }

      // Check for timeout condition
      if (id in conn.tebakkata) {
         clearTimeout(conn.tebakkata[id][3]); // Clear existing timeout if needed
         conn.tebakkata[id][3] = setTimeout(() => {
            if (conn.tebakkata[id]) {
               m.reply(`Waktu habis!\nJawabannya adalah *${conn.tebakkata[id][1].jawaban}*`);
               users.lostgame = (users.lostgame || 0) + 1; // Increment lost game count
               delete conn.tebakkata[id];
            }
         }, 30000); // Adjust the timeout duration as needed
      }

      return true;
   }
};
