module.exports = {
  run: async (m, { conn, usedPrefix, command, args, Func }) => {
    try {
      const type = (args[0] || '').toLowerCase();
      const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
      const validTypes = ['exp', 'money', 'pcoin', 'win', 'limit'];

      if (!validTypes.includes(type)) {
        return conn.reply(m.chat, Func.example(usedPrefix, command, 'Money 10 @628xx'), m);
      }

      const count = args[1] ? parseInt(args[1], 10) : 1;
      if (isNaN(count) || count < 1) {
        return conn.reply(m.chat, Func.texted('Bold', 'Invalid amount. Please specify a valid number greater than 0.'), m);
      }

      if (typeof global.db.data.users[who] === 'undefined') {
        return conn.reply(m.chat, Func.texted('Bold', 'The user does not exist in the database'), m);
      }

      global.db.data.users[who][type] = (global.db.data.users[who][type] || 0) + count;
      conn.reply(m.chat, `Added successfully ${count} ${type}`, m);

    } catch (e) {
      console.log(e);
      conn.reply(m.chat, 'An error occurred while processing your request.', m);
    }
  },
  help: ['pay'],
  use: 'type amount @tag',
  tags: ['owner'],
  command: /^(pay|cheat)$/i,
  owner: true
};