module.exports = {
  run: async (m, { conn, usedPrefix, env, Func, blockList }) => {
    const user = global.db.data.users[m.sender];
    let profilePicPath = './src/image/default.png';

    try {
      profilePicPath = await Func.fetchBuffer(await conn.profilePictureUrl(m.sender, 'image'));
    } catch (err) {
      console.error('Failed to fetch profile picture:', err);
    }

    const now = Date.now();
    const blocked = blockList?.includes(m.sender) ?? false;
    const lastSeenText = user.lastseen ? Func.toDate(now - user.lastseen) : 'Never';
    const useBotText = user.usebot ? Func.toDate(now - user.usebot) : 'Never';
    const isBanned = user.banned || (now - user.ban_temporary < env.timer);
    const banDuration = env.timeout / 60000; // Duration in minutes
    const banText = isBanned ? `${Func.toTime(user.ban_temporary + env.timeout - now)} (${banDuration} min)` : '×';

    let caption = `*[ USER PROFILE ]*\n\n`;
    caption += `*-* *Name*: ${m.name}\n`;
    caption += `*-* *Exp*: ${Func.formatNumber(user.exp)}\n`;
    caption += `*-* *Money*: ${Func.formatNumber(user.money)}\n`;
    caption += `*-* *Limit*: ${Func.formatNumber(user.limit)}\n`;
    caption += `*-* *Hitstat*: ${Func.formatNumber(user.hit)}\n`;
    caption += `*-* *Warning*: ${user.warning + ' / 5'}\n\n`;
    caption += `*[ USER STATUS ]*\n\n`;
    caption += `*-* *Blocked*: ${blocked ? '√' : '×'}\n`;
    caption += `*-* *Banned*: ${banText}\n`;
    caption += `*-* *Use In Private*: ${Object.keys(global.db.data.chats).includes(m.sender) ? '√' : '×'}\n`;
    caption += `*-* *Premium*: ${user.premium ? '√' : '×'}\n`;
    caption += `*-* *Expired*: ${user.expired ? Func.timeReverse(user.expired - now) : '-'}\n`;
    caption += `*-* *Verified*: ${user.registered ? '√' : '×'}\n\n`;
    caption += `*[ WIN GAME ]*\n\n`;
    caption += `*-* *Susunkata*: ${Func.formatNumber(user.winsusunkata)}\n`;
    caption += `*-* *Tebakkata*: ${Func.formatNumber(user.wintebakkata)}\n`;
    caption += `*-* *Tebak Gambar*: ${Func.formatNumber(user.wintebakgambar)}\n`;
    caption += `*-* *Siapakah aku*: ${Func.formatNumber(user.winsiapakahaku)}\n`;
    caption += `*-* *Tebak Bendera*: ${Func.formatNumber(user.wintebakbendera)}\n`;
    caption += `*-* *Teka teki*: ${Func.formatNumber(user.wintekateki)}\n`;
    caption += `*-* *Lengkapi kalimat*: ${Func.formatNumber(user.winlengkapikalimat)}\n\n`;
    caption += global.footer;

    conn.sendMessageModify(m.chat, caption, m, {
      largeThumb: true,
      thumbnail: profilePicPath
    });
  },
  help: ['me'],
  tags: ['user'],
  command: /^(me)$/i,
};