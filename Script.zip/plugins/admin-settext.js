module.exports = {
  run: async (m, { conn, usedPrefix, command, text, participants, Func }) => {
    // Ambil pengaturan grup dari database
    let setup = global.db.data.groups[m.chat]

    // Jika perintah adalah 'setwelcome'
    if (command == 'setwelcome') {
      // Jika teks kosong, kirimkan panduan kepada pengguna
      if (!text) return conn.reply(m.chat, formatWel(usedPrefix, command), m)
      
      // Simpan teks yang diberikan sebagai pesan selamat datang
      setup.sWelcome = text
      
      // Kirim balasan konfirmasi bahwa pesan telah berhasil disimpan
      await conn.reply(m.chat, Func.texted('bold', `Pesan selamat datang berhasil disetel.`), m)
    
    // Jika perintah adalah 'setout' atau 'setleft'
    } else if (/set(out|left)/i.test(command)) {
      // Jika teks kosong, kirimkan panduan kepada pengguna
      if (!text) return conn.reply(m.chat, formatLef(usedPrefix, command), m)
      
      // Simpan teks yang diberikan sebagai pesan perpisahan
      setup.sBye = text
      
      // Kirim balasan konfirmasi bahwa pesan telah berhasil disimpan
      await conn.reply(m.chat, Func.texted('bold', `Pesan perpisahan berhasil disetel.`), m)
    }
  },
  help: ['setwelcome', 'setbye'],
  use: 'text',
  tags: ['admin'],
  command: /^(setwelcome|setbye)$/i,
  group: true,
  admin: true
}

// Format pesan kesalahan dan panduan untuk 'setwelcome'
const formatWel = (prefix, command) => {
  return `Maaf, Anda belum menyertakan teks untuk mengatur pesan selamat datang. Berikut ini adalah penjelasan detail tentang cara menggunakan perintah *${command}*:

1. *+tag*: Gunakan ini di teks untuk secara otomatis menyebutkan member baru yang bergabung. Bot akan menggantikan *+tag* dengan username member tersebut.
2. *+grup*: Gunakan ini untuk menampilkan nama grup di teks pesan. Bot akan menggantikan *+grup* dengan nama grup saat ini.

*Contoh penggunaan perintah:*
${prefix + command} *Halo +tag! Selamat datang di grup +grup. Kami harap kamu betah dan aktif berpartisipasi!*

- Dalam contoh ini, jika ada member baru yang bergabung, *+tag* akan diganti dengan nama pengguna mereka dan *+grup* akan diganti dengan nama grup saat ini.

*Fungsi Utama:*
- Perintah ini membantu Anda menyambut member baru dengan pesan otomatis yang sudah dipersonalisasi. Anda dapat mengatur teks sesuai keinginan, namun pastikan untuk memasukkan placeholder *+tag* dan *+grup* jika ingin menggunakan fitur tersebut.
`
}

// Format pesan kesalahan dan panduan untuk 'setbye'
const formatLef = (prefix, command) => {
  return `Maaf, Anda belum menyertakan teks untuk mengatur pesan perpisahan. Berikut ini adalah penjelasan detail tentang cara menggunakan perintah *${command}*:

1. *+tag*: Gunakan ini di teks untuk menyebutkan member yang keluar dari grup. Bot akan menggantikan *+tag* dengan username member yang meninggalkan grup.
2. *+grup*: Gunakan ini untuk menampilkan nama grup di teks pesan. Bot akan menggantikan *+grup* dengan nama grup saat ini.

*Contoh penggunaan perintah:*
${prefix + command} *Selamat tinggal +tag, semoga sukses di luar sana. Grup +grup akan merindukanmu!*

- Dalam contoh ini, jika ada member yang keluar, *+tag* akan diganti dengan nama pengguna mereka dan *+grup* akan diganti dengan nama grup saat ini.

*Fungsi Utama:*
- Perintah ini memungkinkan Anda mengirim pesan perpisahan secara otomatis kepada member yang keluar dari grup. Seperti pesan selamat datang, pesan perpisahan ini dapat dipersonalisasi dengan *+tag* dan *+grup* untuk memberi kesan lebih personal dan profesional.
`
}