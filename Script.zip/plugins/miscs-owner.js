module.exports = {
  run: async (m, { conn, env }) => {
    conn.sendContact(m.chat, [{
      name: "",
      number: "6285175098705",
      about: 'Owner & Creator'
    }], m, {
      org: 'Bot Support',
      website: 'https://google.com',
      email: 'irugumaa@gmail.com'
    })
  },
  help: ['owner'],
  tags: ['miscs'],
  command: /^(owner|creator)$/i
}