let FormData = require('form-data');

let handler = async (m, { conn, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || q.mediaType || "";
  
  if (!mime) return m.reply(`Fotonya Mana Kak?`);
  if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Mime ${mime} tidak support -_`);

  m.reply('Sedang dalam proses...');

  let img = await q.download?.();
  let error;
  
  try {
    let method;
    if (command === 'enhancer' || command === 'unblur' || command === 'enhance') {
      method = 'enhance';
    } else if (command === 'colorize' || command === 'colorizer') {
      method = 'recolor';
    } else if (command === 'remini' || command === 'hd' || command === 'hdr') {
      method = 'enhance';
    }
    
    const This = await processing(img, method);
    conn.sendFile(m.chat, This, `${method}.jpg`, '', m);
  } catch (er) {
    error = true;
  } finally {
    if (error) {
      m.reply('Proses Gagal :(');
    }
  }
};

handler.help = ['enhancer', 'hdr', 'colorize', 'remini'].map(v => v + ' *[reply photo]*');
handler.tags = ['tools'];
handler.command = ['enhancer', 'hdr', 'colorize', 'remini', 'hd'];
handler.limit = true;

module.exports = handler;

async function processing(urlPath, method) {
  return new Promise(async (resolve, reject) => {
    let Methods = ["enhance", "recolor", "dehaze"];
    method = Methods.includes(method) ? method : Methods[0];
    let buffer, Form = new FormData();
    let scheme = `https://inferenceengine.vyro.ai/${method}`;
    
    Form.append("model_version", 1, { 
      "Content-Transfer-Encoding": "binary",
      contentType: "multipart/form-data; charset=utf-8",
    });
    Form.append("image", Buffer.from(urlPath), {
      filename: "enhance_image_body.jpg",
      contentType: "image/jpeg",
    });
    
    Form.submit({
      url: scheme,
      host: "inferenceengine.vyro.ai",
      path: `/${method}`,
      protocol: "https:",
      headers: {
        "User-Agent": "okhttp/4.9.3",
        Connection: "Keep-Alive",
        "Accept-Encoding": "gzip",
      },
    },
    function (err, res) {
      if (err) reject();
      let data = [];
      res.on("data", function (chunk) {
        data.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(data));
      });
      res.on("error", (e) => {
        reject();
      });
    });
  });
}