module.exports = {
  run: async (m, { conn, usedPrefix, Func }) => {
    let user = global.db.data.users[m.sender]
    if (user.money < 1) return conn.reply(m.chat, `You have no money.`, m)
    
    // Format number to IDR
    const formatToRupiah = (number) => {
      return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(number);
    }
    
    conn.reply(m.chat, `◦ Money : [ ${formatToRupiah(user.money)} ]`, m)
  },
  help: ['money'],
  tags: ['user'],
  command: /^(money)$/i
}