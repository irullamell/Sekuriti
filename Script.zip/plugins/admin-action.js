let handler = async (m, { conn, usedPrefix, command, text, participants, Func }) => {
  // Mendapatkan input dari teks atau balasan atau menyebut JID
  let input = text || (m.quoted ? m.quoted.sender : (m.mentionedJid.length > 0 ? m.mentionedJid[0] : false));
  if (!input) {
    return conn.reply(m.chat, Func.texted('bold', 'Sebut atau balas target yang ingin diubah statusnya.'), m);
  }

  // Memastikan nomor yang dimasukkan adalah valid
  let p = await conn.onWhatsApp(input.trim());
  if (p.length === 0) {
    return conn.reply(m.chat, Func.texted('bold', 'Nomor tidak valid.'), m);
  }

  let jid = conn.decodeJid(p[0].jid);
  let number = jid.replace(/@.+/, '');
  let member = participants.find(u => u.id === jid);

  // Menangani perintah sesuai dengan jenisnya
  switch (command) {
    case 'kick':
      if (!member) {
        return conn.reply(m.chat, Func.texted('bold', `@${number} sudah keluar atau tidak ada di grup ini.`), m);
      }
      await conn.groupParticipantsUpdate(m.chat, [jid], 'remove');
      conn.reply(m.chat, Func.texted('bold', `@${number} telah dikeluarkan dari grup.`), m);
      break;
    case 'promote':
      if (!member) {
        return conn.reply(m.chat, Func.texted('bold', `@${number} sudah keluar atau tidak ada di grup ini.`), m);
      }
      await conn.groupParticipantsUpdate(m.chat, [jid], 'promote');
      conn.reply(m.chat, Func.texted('bold', `@${number} telah diangkat menjadi admin.`), m);
      break;
    case 'demote':
      if (!member) {
        return conn.reply(m.chat, Func.texted('bold', `@${number} sudah keluar atau tidak ada di grup ini.`), m);
      }
      await conn.groupParticipantsUpdate(m.chat, [jid], 'demote');
      conn.reply(m.chat, Func.texted('bold', `@${number} telah diturunkan dari jabatan admin.`), m);
      break;
  }
};

// Help documentation and command metadata
handler.help = ["kick", "promote", "demote"];
handler.tags = ["admin"];
handler.command = ["promote", "kick", "demote"];

module.exports = handler;