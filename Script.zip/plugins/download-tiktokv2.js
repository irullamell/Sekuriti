const axios = require('axios');

let handler = async (m, { usedPrefix, command, args, Func }) => {
  if (!args[0]) return m.reply(Func.example(usedPrefix, command, 'https://vt.tiktok.com/ZSYaEoF55'));
  if (!args[0].match('tiktok.com')) return m.reply(global.status.invalid);

  m.react('⏱️');
  
  try {
    const apiUrl = `https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(args[0])}`;
    const { data } = await axios.get(apiUrl);
    
    if (!data || (!data.video?.noWatermark && !data.images?.length && !data.music?.play_url)) {
      return m.reply('Tidak ada konten yang ditemukan. Pastikan URL Tiktok valid.');
    }

    let teks = `*[ Tiktok Downloader ]*\n\n`;
    teks += `*-* *ID* : ${data.id || "Tidak ada"}\n`;
    teks += `*-* *Region* : ${data.region || "Tidak ada"}\n`;
    teks += `*-* *Nama* : ${data.author?.nickname || "Tidak ada"}\n`;
    teks += `*-* *Username* : ${data.author?.unique_id || "Tidak ada"}\n`;
    teks += `*-* *Durasi* : ${data.duration || "Tidak ada"} detik\n`;
    teks += `*-* *Dilihat* : ${data.play_count || "Tidak ada"}\n`;
    teks += `*-* *Komentar* : ${data.comment_count || "Tidak ada"}\n`;
    teks += `*-* *Dibagikan* : ${data.share_count || "Tidak ada"}\n`;
    teks += `*-* *Diunduh* : ${data.download_count || "Tidak ada"}\n`;
    teks += `*-* *Judul* : ${data.title || "Tidak ada"}\n\n`;
    teks += global.footer;

    const videoUrl = data.video?.noWatermark;
    const musicUrl = data.music?.play_url;
    const images = data.images;

    // Handle images if present
    if (images && images.length > 0) {
      for (let img of images) {
        await conn.sendFile(m.chat, img.url, Func.filename('jpg'), '', m);
      }
    }

    // Handle video if available
    if (videoUrl) {
      const ttvideo = await conn.sendFile(m.chat, videoUrl, Func.filename('mp4'), teks, m);

      // If audio is available, send it
      if (musicUrl) {
        await conn.sendFile(m.chat, musicUrl, Func.filename('mp3'), '', ttvideo);
      }
    } else if (musicUrl) {
      // If only audio is available, send audio
      await conn.sendFile(m.chat, musicUrl, Func.filename('mp3'), teks, m);
    } else {
      return m.reply('Konten video atau audio tidak ditemukan.');
    }

  } catch (error) {
    console.error(error);
    return m.reply('Maaf, terjadi kesalahan saat mengambil data. Silakan coba lagi.');
  }
};

handler.help = ['tiktokv2'].map(v => v + ' *url*');
handler.tags = ['downloader'];
handler.command = ['tiktokv2'];
handler.limit = 1;

module.exports = handler;