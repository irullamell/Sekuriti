module.exports = {
  run: async (m, { conn, command, args, isAdmin, isOwner, groupSet, setting }) => {
    const isEnable = /true|enable|(turn)?on|1/i.test(command);
    const type = (args[0] || '').toLowerCase();
    const groupOptions = ['welcome', 'detect', 'antidelete', 'antilink', 'autoclose', 'antich', 'antivirtex', 'autosticker', 'antisticker', 'viewonce', 'filter'];
    const botOptions = ['anticall', 'chatbot', 'self', 'online', 'antispam', 'debug', 'groupmode', 'privatemode', 'game', 'rpg'];

    // Helper for checking permissions and replying
    const checkPermissions = (isGroupSetting = false) => {
      if (!isOwner && (!m.isGroup || (isGroupSetting && !isAdmin))) {
        conn.reply(m.chat, m.isGroup ? global.status.admin : global.status.owner, m);
        throw false;
      }
    };

    // Handle group settings
    const handleGroupSetting = () => {
      checkPermissions(true);
      groupSet[type] = isEnable;
      conn.reply(m.chat, `*${type}* successfully *${isEnable ? 'enabled' : 'disabled'}* for this group.`, m);
    };

    // Handle bot settings
    const handleBotSetting = () => {
      checkPermissions();
      setting[type] = isEnable;
      conn.reply(m.chat, `*${type}* successfully *${isEnable ? 'enabled' : 'disabled'}* for this bot.`, m);
    };

    // Main logic to handle the type
    if (groupOptions.includes(type)) {
      handleGroupSetting();
    } else if (botOptions.includes(type)) {
      handleBotSetting();
    } else {
      // Show options if type is not recognized
      const optionsList = `
        乂  *O P T I O N*\n
        ${isOwner ? botOptions.map(v => '  ◦  ' + v).join('\n') : ''}
        ${m.isGroup ? groupOptions.map(v => '  ◦  ' + v).join('\n') : ''}
        \n\n${global.footer}`;
      conn.reply(m.chat, optionsList, m);
    }
  },

  help: ['en', 'dis'].map(v => v + 'able'),
  use: 'option',
  tags: ['admin', 'owner'],
  command: /^(on|off|enable|disable)$/i
};