module.exports = {
  run: async (m, { conn, command, Func }) => {
    try {
      // URL file JSON untuk dare dan truth
      const urls = {
        dare: 'https://raw.githubusercontent.com/Iruchikaa/power-data/refs/heads/main/dare.json',
        truth: 'https://raw.githubusercontent.com/Iruchikaa/power-data/refs/heads/main/truth.json'
      };

      // Ambil URL berdasarkan command
      const url = urls[command.toLowerCase()];
      
      if (url) {
        // Ambil JSON dari URL yang sesuai
        const json = await Func.fetchJson(url);

        // Pilih secara acak satu entri dari JSON
        const message = json[Math.floor(Math.random() * json.length)];

        // Kirimkan pesan balasan
        conn.reply(m.chat, `${message}\n\n*By s.id/powerbot*`, m);
      }
    } catch (e) {
      // Tampilkan error di log jika ada
      console.error(`Error executing ${command}:`, e);
    }
  },
  help: ['dare', 'truth'],
  tags: ['fun'],
  command: /^(truth|dare)$/i,
  limit: true
};