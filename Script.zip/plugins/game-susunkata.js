module.exports = {
   run: async (m, { conn, usedPrefix, command, Func, users }) => {
      conn.susunkata = conn.susunkata || {};
      let id = m.chat;
      let timeout = 30000;
      let poin = Func.randomInt('500', '1200');

      if (command === 'susunkata') {
         if (id in conn.susunkata) {
            return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.susunkata[id][0]);
         }

         let src = await Func.fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json');
         let json = src[Math.floor(Math.random() * src.length)];

         let capt = `乂 *S U S U N K A T A*\n\n`;
         capt += `${json.soal}\n\n`;
         capt += `Tipe : ${json.tipe}\n`;
         capt += `Timeout : ${timeout / 60 / 1000} menit\n`;
         capt += `Balas pesan ini untuk menjawab, kirim ${usedPrefix}suska untuk bantuan`;

         conn.susunkata[id] = [
            await conn.reply(m.chat, capt, m),
            json,
            poin,
            setTimeout(() => {
               if (conn.susunkata[id]) {
                  conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.susunkata[id][0]);
                  
                  // Increment lostgame count
                  users.lostgame = (users.lostgame || 0) + 1;

                  delete conn.susunkata[id];
               }
            }, timeout)
         ];
      } else if (command === 'suska') {
         if (!(id in conn.susunkata)) throw false;

         // Deduct 3% from the points/reward for using a hint
         let originalPoin = conn.susunkata[id][2];
         let deduction = Math.floor(originalPoin * 0.03); // 3% deduction
         let newPoin = originalPoin - deduction;

         // Update points in the game session
         conn.susunkata[id][2] = newPoin;

         // Inform the user about the deduction
         conn.reply(m.chat, `Menggunakan hint akan mengurangi hadiah Anda sebesar 3%.\nHadiah saat ini: ${newPoin} poin (setelah pengurangan)`, conn.susunkata[id][0]);

         // Provide the hint
         let clue = conn.susunkata[id][1].jawaban.replace(/[AIUEOaiueo]/g, '_');
         conn.reply(m.chat, '```' + clue + '```\nBalas soalnya, bukan pesan ini', conn.susunkata[id][0]);
      }
   },
   help: ['susunkata'],
   tags: ['game'],
   command: /^(susunkata|suska)$/i,
   group: true,
   game: true,
   limit: true
};