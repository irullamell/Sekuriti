const axios = require("axios");
const FormData = require("form-data");
const cheerio = require("cheerio");

// Function to download TikTok videos using the Savetik API
async function tiktokdl(url) {
  const bodyForm = new FormData();
  bodyForm.append("q", url);
  bodyForm.append("lang", "id");

  try {
    const response = await axios.post("https://savetik.co/api/ajaxSearch", bodyForm, {
      headers: {
        "Content-Type": `multipart/form-data; boundary=${bodyForm._boundary}`,  // Correctly define the Content-Type
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
      }
    });

    const $ = cheerio.load(response.data.data);
    return {
      status: true,
      caption: $("div.video-data > div > .tik-left > div > .content > div > h3").text(),
      server1: {
        quality: "MEDIUM",
        url: $("div.video-data > div > .tik-right > div > p:nth-child(1) > a").attr("href"),
      },
      serverHD: {
        quality: $("div.video-data > div > .tik-right > div > p:nth-child(3) > a").text().split("MP4 ")[1],
        url: $("div.video-data > div > .tik-right > div > p:nth-child(3) > a").attr("href"),
      },
      audio: $("div.video-data > div > .tik-right > div > p:nth-child(4) > a").attr("href"),
    };
  } catch (err) {
    console.error("Error fetching TikTok data:", err);
    return { status: false, message: "Failed to fetch TikTok data." };
  }
}

// Handler function to process the command
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`*Wrong input*\n\nExample: ${usedPrefix + command} https://vm.tiktok.com/ZSL7p9jRV/`);
  }

  conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

  try {
    const videoData = await tiktokdl(text);
    if (!videoData.status) {
      throw new Error(videoData.message);
    }

    const caption = `乂 *T I K T O K*\n\n*Description:* ${videoData.caption}`;
    await conn.sendMessage(m.chat, { video: { url: videoData.serverHD.url }, caption }, { quoted: m });
  } catch (error) {
    m.reply(error.message || "Error fetching TikTok data.");
  } finally {
    conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  }
};

// Command metadata
handler.help = ['tiktokhd <link>'];
handler.tags = ['downloader'];
handler.command = /^(tiktokhd|tthd)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;