const moment = require('moment'); // Import the moment library
const { createCanvas, loadImage } = require('canvas'); // Import the canvas library and loadImage
const fs = require('fs'); // For saving the canvas image temporarily
const Chart = require('chart.js/auto'); // Correctly import Chart.js for Node.js

module.exports = {
  run: async (m, { conn, Func }) => {
    let stats = Object.entries(global.db.data.stats).map(([key, val]) => {
      let name = Array.isArray(plugins[key]?.help) ? plugins[key]?.help.join(' & ') : plugins[key]?.help || key;
      if (/exec/.test(name)) return;
      return { name, category: plugins[key]?.tags || 'uncategorized', ...val };
    }).filter(v => v); // Filter out undefined values

    // Get filter type (e.g., 'today', 'week', 'month') from command arguments
    const timeFilter = m.text.split(' ')[1] || 'all';
    const now = moment();
    let filteredStats;

    // Filter by time period
    switch (timeFilter) {
      case 'today':
        filteredStats = stats.filter(stat => moment(stat.last).isSame(now, 'day'));
        break;
      case 'week':
        filteredStats = stats.filter(stat => moment(stat.last).isSame(now, 'week'));
        break;
      case 'month':
        filteredStats = stats.filter(stat => moment(stat.last).isSame(now, 'month'));
        break;
      default:
        filteredStats = stats;
        break;
    }

    // Sort stats by total hits
    filteredStats = filteredStats.sort((a, b) => b.total - a.total);

    // Group by category
    let categorizedStats = {};
    filteredStats.forEach(({ category, ...stat }) => {
      if (!categorizedStats[category]) categorizedStats[category] = [];
      categorizedStats[category].push(stat);
    });

    // Prepare data for chart visualization
    const topCommands = filteredStats.slice(0, 10); // Get top 10 commands
    const commandNames = topCommands.map(stat => stat.name);
    const commandHits = topCommands.map(stat => stat.total);

    // Create the chart
    const canvas = createCanvas(1400, 1000); // Larger canvas for more complex visuals
    const ctx = canvas.getContext('2d');

    // Create gradient background for bars
    const gradient = ctx.createLinearGradient(0, 0, 0, 600);
    gradient.addColorStop(0, 'rgba(255, 99, 132, 0.2)');
    gradient.addColorStop(1, 'rgba(54, 162, 235, 0.2)');

    // Load a background image
    const backgroundImage = await loadImage('./src/image/thumbnail.jpg'); // Corrected loadImage usage
    ctx.drawImage(backgroundImage, 0, 0, 1400, 1000); // Place background image

    const chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: commandNames,
        datasets: [
          {
            label: 'Command Hits',
            data: commandHits,
            backgroundColor: gradient,
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 3,
            hoverBorderColor: 'rgba(255, 99, 132, 1)',
            hoverBorderWidth: 5,
            barPercentage: 0.6, // Adjust bar width
            categoryPercentage: 0.5, // Adjust spacing
            borderRadius: 20, // Rounded corners for bars
            shadowOffsetX: 4, // Adding shadow effects
            shadowOffsetY: 4,
            shadowBlur: 10,
            shadowColor: 'rgba(0, 0, 0, 0.3)',
          },
          {
            label: 'Usage Percentage (%)',
            data: commandHits.map(h => (h / commandHits.reduce((a, b) => a + b)) * 100),
            type: 'line',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 4,
            fill: true,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            pointBackgroundColor: 'rgba(75, 192, 192, 1)',
            pointBorderColor: '#fff',
            pointBorderWidth: 3,
            pointRadius: 6,
            pointHoverRadius: 8,
            tension: 0.3, // Smooth curves
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 16,
                weight: 'bold'
              },
              color: '#333',
              maxRotation: 45, // Rotate labels if they are too long
            }
          },
          y: {
            grid: {
              color: 'rgba(200, 200, 200, 0.3)',
              borderDash: [5, 5]
            },
            beginAtZero: true,
            ticks: {
              font: {
                size: 14,
                weight: 'bold',
              },
              color: '#333',
              callback: function(value) {
                return value + ' hits'; // Add 'hits' suffix to Y-axis values
              }
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: `Top 10 Commands Used (${timeFilter})`,
            font: {
              size: 28,
              weight: 'bold',
              family: 'Arial',
            },
            color: '#222',
            padding: {
              top: 20,
              bottom: 30
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 18,
                style: 'italic'
              },
              color: '#222'
            }
          },
          tooltip: {
            enabled: true,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            borderColor: 'rgba(255, 255, 255, 0.3)',
            borderWidth: 3,
            cornerRadius: 10,
            titleFont: {
              size: 18,
              weight: 'bold'
            },
            bodyFont: {
              size: 16
            },
            callbacks: {
              label: function(context) {
                let label = `${context.dataset.label}: ${context.raw}`;
                if (context.datasetIndex === 1) {
                  label += '%';
                }
                return label;
              },
              footer: function() {
                const totalHits = commandHits.reduce((a, b) => a + b, 0);
                return `Total Hits: ${totalHits}`;
              }
            }
          }
        },
        animation: {
          duration: 2500,
          easing: 'easeOutElastic', // Elastic animation for more dynamic effect
          onProgress: function(animation) {
            // Create an animated progress bar at the top
            const progress = animation.currentStep / animation.numSteps;
            ctx.fillStyle = 'rgba(0, 123, 255, 0.5)';
            ctx.fillRect(0, 0, canvas.width * progress, 10);
          },
          onComplete: function() {
            const chartInstance = this.chart;
            const ctx = chartInstance.ctx;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            ctx.fillStyle = '#000';
            chartInstance.data.datasets.forEach(function(dataset, i) {
              const meta = chartInstance.getDatasetMeta(i);
              meta.data.forEach(function(point, index) {
                const data = dataset.data[index];
                ctx.fillText(data, point.x, point.y - 10);
              });
            });
          }
        }
      }
    });

    // Save the chart to a file
    const buffer = canvas.toBuffer('image/png');
    const imagePath = './complex_chart_with_bg.png';
    fs.writeFileSync(imagePath, buffer);

    // Send the image to the chat
    await conn.sendFile(m.chat, imagePath, 'complex_chart_with_bg.png', '*[ HIT STATUS ]*\n\nHere is the highly enhanced visual representation of the command hits.', m);

    // Remove the image file after sending it
    fs.unlinkSync(imagePath);
  },
  help: ['hitstat [today|week|month]'],
  tags: ['misc'],
  command: /^(hitstat)$/i
};