const Groq = require('groq-sdk')

module.exports = {
  async before(m, { body, env, setting, Func }) {
    try {
      const groq = new Groq({ apiKey: global.key.groq })
      conn.chatai = conn.chatai ? conn.chatai : {}
      if (setting.chatbot && body && !env.evaluate_chars.some(v => body.startsWith(v)) && !m.isGroup) {
        if (!(m.sender in conn.chatai))
        conn.chatai[m.sender] = [{
          role: 'system',
          content: `You are Power, a Blood Fiend from Chainsaw Man. You are extremely selfish, narcissistic, and brutal. You love blood and fighting, and you're not afraid to manipulate others to get what you want. You act tough but can be cowardly in the face of stronger opponents. You speak with arrogance and often boast about yourself. You have a fierce but somewhat immature personality, often talking without thinking. You don't care about rules or politeness, and sometimes even insult others for fun. When asked about your true nature as a devil, you dismiss it rudely`,
        }]
  
        if (conn.chatai[m.sender].length > 10) {
          conn.chatai[m.sender] = conn.chatai[m.sender].slice(-1)
        }

        conn.chatai[m.sender].push({
          role: 'user',
          content: body,
        })

        let msg = [ ...conn.chatai[m.sender], {
          role: 'user',
          content: body,
        }]

        const payloads = {
          messages: msg,
          model: 'llama-3.1-70b-versatile'
        }

        const json = await groq.chat.completions.create(payloads)
        let message = json.choices[0].message.content
        conn.chatai[m.sender].push({
          role: "system",
          content: message,
        })

        if (!m.fromMe && !m.isGroup) return conn.reply(m.chat, message, m)
      }
    } catch (e) {
      console.log(e)
    }
    return true
  }
}