const { Youtube } = require('@neoxr/youtube-scraper');
const fetch = require('node-fetch'); // Ensure you have node-fetch installed
const yt = new Youtube({
   fileAsUrl: false
});

const handler = async (m, { conn, text, isPrefix, command }) => {
   try {
      if (!text) return conn.reply(m.chat, `Example: ${isPrefix}${command} lathi`, m);

      // Fetch YouTube data using @neoxr/youtube-scraper
            m.react('⏱️');
      const json = await yt.play(text);
      if (!json.status) return conn.reply(m.chat, JSON.stringify(json), m);

      // Prepare caption with YouTube video details
      let caption = `乂  *Y T - P L A Y*\n\n`;
      caption += `	◦  *Title* : ${json.title}\n`;
      caption += `	◦  *Size* : ${json.data.size}\n`;
      caption += `	◦  *Duration* : ${json.duration}\n`;
      caption += `	◦  *Bitrate* : ${json.data.quality}\n\n`;
      caption += global.footer;

      // Fetch thumbnail image as a buffer
      const thumbnailBuffer = await (await fetch(json.thumbnail)).buffer();

      // Send the modified message with thumbnail and YouTube file
      await conn.sendMessageModify(m.chat, caption, m, {
         largeThumb: true,
         thumbnail: json.thumbnail
      }).then(async () => {
         await conn.sendFile(m.chat, json.data.url, json.data.filename, '', m, {
            document: false,
            APIC: thumbnailBuffer // Use fetched buffer for the thumbnail image
         });
      });
   } catch (e) {
      conn.reply(m.chat, `Error: ${e.message}`, m);
   }
};

handler.help = ['play'].map(v => v + ' *title*');
handler.tags = ['downloader'];
handler.command = ['play'];
handler.limit = 1;

module.exports = handler;