const { Converter } = new (require('@im-dims/wb'))
const fs = require('fs')
const { exec } = require('child_process')

module.exports = {
  run: async (m, { conn, usedPrefix, command, text, Func }) => {
    try {
      const exif = global.db.data.setting;
      const quoted = m.quoted || m;
      const message = quoted.message || m.msg.viewOnce;

      // Cek apakah media adalah viewOnce atau pesan yang di-quote
      if (message) {
        const type = quoted.message ? Object.keys(quoted.message)[0] : m.mtype;
        const content = quoted.message ? quoted.message[type] : m.msg;
        const media = await conn.downloadMediaMessage(content);

        // Penanganan video
        if (/video/.test(type)) {
          if (content.seconds > 10) {
            return conn.reply(m.chat, Func.texted('bold', 'Maximum video duration is 10 seconds.'), m);
          }
          return await conn.sendSticker(m.chat, media, m, {
            packname: exif.sk_pack,
            author: exif.sk_author || 's.id/powerbot'
          });
        }

        // Penanganan gambar
        if (/image/.test(type)) {
          return await conn.sendSticker(m.chat, media, m, {
            packname: exif.sk_pack,
            author: exif.sk_author || 's.id/powerbot'
          });
        }

        // Media tidak didukung
        return conn.reply(m.chat, Func.texted('bold', 'Invalid media type. Only image and video are supported.'), m);
      } else {
        // Penanganan media selain viewOnce/quoted
        const mime = (quoted.msg || quoted).mimetype || '';

        if (/image\/(jpe?g|png)/.test(mime)) {
          const img = await quoted.download();
          if (!img) return conn.reply(m.chat, global.status.wrong, m);

          return await conn.sendSticker(m.chat, img, m, {
            packname: exif.sk_pack,
            author: exif.sk_author || 's.id/powerbot'
          });
        }

        if (/video/.test(mime)) {
          if ((quoted.msg || quoted).seconds > 10) {
            return conn.reply(m.chat, Func.texted('bold', 'Maximum video duration is 10 seconds.'), m);
          }

          const video = await quoted.download();
          if (!video) return conn.reply(m.chat, global.status.wrong, m);

          return await conn.sendSticker(m.chat, video, m, {
            packname: exif.sk_pack,
            author: exif.sk_author || 's.id/powerbot'
          });
        }

        return conn.reply(m.chat, Func.texted('bold', 'Please send an image or video with caption #s.'), m);
      }
    } catch (error) {
      console.error('Sticker Conversion Error:', error);
      return conn.reply(m.chat, Func.texted('bold', 'An error occurred during the sticker conversion.\n\n> Reply foto/video dengan caption #s'), m);
    }
  },
  help: ['sticker'],
  use: 'query / reply media',
  tags: ['converter'],
  command: ['s', 'sticker', 'stiker', 'setiker'],
  limit: true
}