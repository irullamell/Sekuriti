const { MessageType } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, usedPrefix, args, command, Func }) => {
  // Check if arguments are provided
  if (!args || args.length < 2) {
    return m.reply(`Penggunaan yang benar:\n` +
      `1. Untuk menambahkan money: \n` +
      `   \`${usedPrefix}+money 6285955204711 1000\`\n` +
      `2. Untuk mengurangi money:\n` +
      `   \`${usedPrefix}-money 6285955204711 500\`\n` +
      `3. Untuk mengatur money:\n` +
      `   \`${usedPrefix}setmoney 6285955204711 1500\`\n` +
      `*Pastikan nomor yang digunakan dalam format: 62xxxxxxxxxx*`);
  }

  // Mark the chat as read
  conn.chatRead(m.chat);
  
  // Send a loading reaction
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  // Extract and trim the number and points from args
  let [number, points] = args.join(' ').split(' ').map(arg => arg.trim());
  
  // Validate the phone number format
  if (!/^\d{10,15}$/.test(number)) {
    throw 'Masukkan nomor pengguna yang valid. Contoh: 6285955204711';
  }

  let mentionedJid = number + '@s.whatsapp.net';
  let users = global.db.data.users;

  // Create a new user entry if it doesn't exist
  if (!users[mentionedJid]) {
    users[mentionedJid] = { money: 0, exp: 0, lastclaim: 0 };
  }

  // Parse and validate the points
  let pointsInt = parseInt(points);
  if (isNaN(pointsInt) || pointsInt <= 0) {
    throw `Jumlah money harus berupa angka positif. Contoh: .${command} 6285955204711 1000`;
  }

  // Handle money operations based on the command
  switch (command) {
    case '+money':
      users[mentionedJid].money += pointsInt;
      conn.reply(m.chat, `Berhasil menambahkan ${pointsInt} money untuk nomor ${number}.`, m, {
        mentions: [mentionedJid]
      });
      break;

    case '-money':
      if (users[mentionedJid].money < pointsInt) {
        throw `money pengguna tidak cukup. Pengguna saat ini memiliki ${users[mentionedJid].money} money.`;
      }
      users[mentionedJid].money -= pointsInt;
      conn.reply(m.chat, `Berhasil mengurangi ${pointsInt} money untuk nomor ${number}. Sisa money sekarang: ${users[mentionedJid].money}`, m, {
        mentions: [mentionedJid]
      });
      break;

    case 'setmoney':
      users[mentionedJid].money = pointsInt;
      conn.reply(m.chat, `money untuk nomor ${number} telah diatur menjadi ${pointsInt}.`, m, {
        mentions: [mentionedJid]
      });
      break;

    default:
      throw 'Perintah tidak dikenal. Silakan gunakan +money, -money, atau setmoney.';
  }

  // Send a success reaction
  conn.sendMessage(m.chat, {
    react: {
      text: '✅',
      key: m.key,
    }
  });
};

handler.help = ['+money nomor jumlah', '-money nomor jumlah', 'setmoney nomor jumlah'];
handler.tags = ['owner'];
handler.command = ["+money", "-money", "setmoney"]; // All money-related commands
handler.owner = true;

module.exports = handler;