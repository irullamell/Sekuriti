const axios = require("axios"); 

const handler = async (m, { conn, text, usedPrefix, command, Func }) => {
    switch (command) {
        case "spotify": {
            if (!text) return m.reply(Func.example(usedPrefix, command, 'Oh asmara'))
            let isUrl = text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, "gi")) || false
            m.reply(isUrl ? "Downloading..." : "Searching.....");
            if (isUrl) {
                for (let i of isUrl) {
                    let {
                        data
                    } = await axios.get(`https://api.botwa.space/api/spotify/download?url=${i}&apikey=57zQWe5etGWy`).catch((e) => e.response);
                    if (data.status !== 200) return m.reply("Request Download Gagal !");
                    let cap = `*+ S P O T I F Y*

- *Metadata :*
${Object.entries(data.result).map(([a, b]) => `- ${a} : ${b}`).join("\n")}`
                    let q = await conn.sendMessage(m.chat, {
                        text: cap
                    }, {
                        quoted: m
                    });
                    await conn.sendMessage(m.chat, {
                        audio: {
                            url: data.result.download
                        },
                        mimetype: "audio/mpeg",
                        contextInfo: {
                            externalAdReply: {
                                title: "Success Download !",
                                body: `- Title : ${data.result.title}`,
                                mediaType: 2,
                                mediaUrl: i,
                                thumbnailUrl: data.result.image,
                                renderLangerThumbnail: true,
                                sourceUrl: i
                            }
                        }
                    }, {
                        quoted: q
                    })
                }
            } else {
                let {
                    data
                } = await axios.get(`https://api.botwa.space/api/spotify/search?q=${text}&apikey=57zQWe5etGWy`).catch((e) => e.response);
                if (data.status !== 200) return m.reply("Request Download Gagal !");
                let cap = `*+ S P O T I F Y*
Spotify Search by ${data.creator}
Download music input command :
*• Example :* .spotify https://open.spotify.com/xxxx

* *Results [ ${data.result.length} ] :*
${data.result.map((a, i) => `- number : ${i+1}
${Object.entries(a).map(([a, b]) => `- ${a} : ${b.track ? `${b.track}\n- preview : ${b.preview}`: b}`).join("\n")}`).join("\n\n")}`
                await conn.sendMessage(m.chat, {
                    text: cap
                }, {
                    quoted: m
                })
            }
        }
        break
    }
}
handler.help = handler.command = ["spotify"]
handler.tags = ["downloader"]

module.exports = handler