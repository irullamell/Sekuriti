const { Youtube } = require('@neoxr/youtube-scraper');
const { youtubedl } = require('@bochilteam/scraper-sosmed');
const fetch = require('node-fetch'); // Pastikan node-fetch versi 3.x diinstall
const yt = new Youtube({
   fileAsUrl: false
});

const handler = async (m, { conn, args, isPrefix, command, Func }) => {
   try {
      if (/yt?(a|mp3)/i.test(command)) {
         if (!args[0]) return m.reply(Func?.example ? Func.example(isPrefix, command, 'https://youtu.be/cK5EQ-WAdKU?si=OPbwnlsB4Rga9_RE') : `Contoh: ${isPrefix}${command} https://youtu.be/cK5EQ-WAdKU`);
         if (!isValidYoutubeUrl(args[0])) return conn.reply(m.chat, 'Link YouTube tidak valid.', m);

         let json;
         try {
            // Coba ambil data audio dari @neoxr/youtube-scraper
            json = await yt.fetch(args[0], 'audio');
            if (!json.status) throw new Error('Gagal mendapatkan data dari @neoxr/youtube-scraper.');
         } catch (e) {
            console.error('Error menggunakan @neoxr/youtube-scraper, menggunakan fallback @bochilteam/scraper-sosmed:', e.message);

            // Fallback ke @bochilteam/scraper-sosmed jika @neoxr gagal
            const data = await youtubedl(args[0]);
            const qualityOptions = Object.keys(data.audio);
            const selectedQuality = qualityOptions[0]; // Menggunakan kualitas pertama sebagai default

            json = {
               title: data.title,
               data: {
                  url: await data.audio[selectedQuality].download(),
                  filename: `${data.title}.mp3`,
                  size: data.audio[selectedQuality].fileSizeH,
                  quality: selectedQuality,
               },
               duration: data.duration,
               thumbnail: data.thumbnail
            };
         }

         // Caption hasil download
         let caption = `乂  *Y T - M P 3*\n\n`;
         caption += `	◦  *Judul* : ${json.title}\n`;
         caption += `	◦  *Ukuran* : ${json.data.size}\n`;
         caption += `	◦  *Durasi* : ${json.duration}\n`;
         caption += `	◦  *Bitrate* : ${json.data.quality}\n\n`;
         caption += 'Enjoy your music!';

         // Mengirim file MP3
         const thumbnailBuffer = await fetchBuffer(json.thumbnail);
         conn.sendMessageModify(m.chat, caption, m, {
            largeThumb: true,
            thumbnail: thumbnailBuffer
         }).then(async () => {
            await conn.sendFile(m.chat, json.data.url, json.data.filename, '', m, {
               document: false,
               APIC: thumbnailBuffer
            });
         });
      } else if (/yt?(v|mp4)/i.test(command)) {
         if (!args || !args[0]) return conn.reply(m.chat, `Contoh: ${isPrefix}${command} https://youtu.be/zaRFmdtLhQ8`, m);
         if (!isValidYoutubeUrl(args[0])) return conn.reply(m.chat, 'Link YouTube tidak valid.', m);

         let json;
         try {
            // Coba ambil data video dari @neoxr/youtube-scraper
            json = await yt.fetch(args[0], 'video', '720p');
            if (!json.status) throw new Error('Gagal mendapatkan data dari @neoxr/youtube-scraper.');
         } catch (e) {
            console.error('Error menggunakan @neoxr/youtube-scraper, menggunakan fallback @bochilteam/scraper-sosmed:', e.message);

            // Fallback ke @bochilteam/scraper-sosmed jika @neoxr gagal
            const data = await youtubedl(args[0]);
            const qualityOptions = Object.keys(data.video);
            const selectedQuality = qualityOptions[0]; // Menggunakan kualitas pertama sebagai default

            json = {
               title: data.title,
               data: {
                  url: await data.video[selectedQuality].download(),
                  filename: `${data.title}.mp4`,
                  size: data.video[selectedQuality].fileSizeH,
                  quality: selectedQuality,
               },
               duration: data.duration,
               thumbnail: data.thumbnail
            };
         }

         // Caption hasil download
         let caption = `乂  *Y T - M P 4*\n\n`;
         caption += `	◦  *Judul* : ${json.title}\n`;
         caption += `	◦  *Ukuran* : ${json.data.size}\n`;
         caption += `	◦  *Durasi* : ${json.duration}\n`;
         caption += `	◦  *Kualitas* : ${json.data.quality}\n\n`;
         caption += 'Enjoy your video!';

         // Mengirim file MP4
         const thumbnailBuffer = await fetchBuffer(json.thumbnail);
         conn.sendMessageModify(m.chat, caption, m, {
            largeThumb: true,
            thumbnail: thumbnailBuffer
         }).then(async () => {
            await conn.sendFile(m.chat, json.data.url, json.data.filename, caption, m, {
               document: false
            });
         });
      }
   } catch (e) {
      return conn.reply(m.chat, `Error: ${e.message || e}`, m);
   }
};

// Helper function untuk mengambil thumbnail sebagai buffer
async function fetchBuffer(url) {
   const res = await fetch(url);
   const arrayBuffer = await res.arrayBuffer();
   return Buffer.from(arrayBuffer); // Konversi ArrayBuffer ke Buffer
}

// Helper function untuk validasi URL YouTube
function isValidYoutubeUrl(url) {
   const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
   return regex.test(url);
}

handler.help = ['ytmp3', 'ytmp4'];
handler.tags = ['downloader'];
handler.command = ['ytmp3', 'ytmp4', 'yta', 'ytv'];

module.exports = handler;