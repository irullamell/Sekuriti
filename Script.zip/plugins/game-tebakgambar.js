module.exports = {
   run: async (m, { conn, usedPrefix, command, Func, users }) => {
      conn.tebakgambar = conn.tebakgambar ? conn.tebakgambar : {};
      let id = m.chat;
      let timeout = 30000;
      let poin = Func.randomInt('500', '2000');

      if (command === 'tebakgambar') {
         if (id in conn.tebakgambar) {
            return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebakgambar[id][0]);
         }

         let src = await Func.fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json');
         let json = src[Math.floor(Math.random() * src.length)];
         let capt = `乂  *T E B A K G A M B A R*\n\n`;
         capt += `${json.deskripsi}\n\n`;
         capt += `*Timeout :* [ ${timeout / 60 / 1000} menit ]\n`;
         capt += `Balas pesan ini untuk menjawab, kirim ${usedPrefix}hint untuk bantuan`;

         conn.tebakgambar[id] = [
            await conn.sendMessage(m.chat, { image: { url: json.img }, caption: capt }, { quoted: m }),
            json,
            poin,
            setTimeout(() => {
               if (conn.tebakgambar[id]) {
                  conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*\n\n> Ketik #tebakgambar untuk bermain lagi`, conn.tebakgambar[id][0]);

                  // Increment lost game count
                  users.lostgame = (users.lostgame || 0) + 1;
                  delete conn.tebakgambar[id];
               }
            }, timeout)
         ];
      } else if (command === 'hint') {
         if (!(id in conn.tebakgambar)) throw false;

         // Deduct 1% from the points/reward for using a hint
         let originalPoin = conn.tebakgambar[id][2];
         let deduction = Math.floor(originalPoin * 0.01); // 1% deduction
         let newPoin = originalPoin - deduction;

         // Update points in the game session
         conn.tebakgambar[id][2] = newPoin;

         // Inform the user about the deduction
         conn.reply(m.chat, `Menggunakan hint akan mengurangi hadiah Anda sebesar 1%.\nHadiah saat ini: ${newPoin} poin (setelah pengurangan)`, conn.tebakgambar[id][0]);

         // Provide the hint
         let clue = conn.tebakgambar[id][1].jawaban.replace(/[AIUEOaiueo]/g, '_');
         conn.reply(m.chat, '```' + clue + '```\nBalas soalnya, bukan pesan ini', conn.tebakgambar[id][0]);
      }
   },
   help: ['tebakgambar'],
   tags: ['game'],
   command: /^(tebakgambar|hint)$/i,
   group: true,
   game: true,
   limit: true
};