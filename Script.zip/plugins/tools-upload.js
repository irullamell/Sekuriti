const axios = require("axios");
const FormData = require("form-data");

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

let handler = async (m, { conn }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  // Validate media existence
  if (!mime) {
    return m.reply('⛩️ Tidak ada media yang ditemukan.');
  }

  // Download the media
  let media;
  try {
    media = await q.download();
  } catch (error) {
    console.error('Error downloading media:', error);
    return m.reply('⛩️ Gagal mengunduh media. Silakan coba lagi.');
  }

  // Validate file size
  if (media.length > MAX_FILE_SIZE) {
    return m.reply('⛩️ File melebihi ukuran maksimum 5 MB.');
  }

  // Attempt to upload the media
  try {
    const result = await uploadPomf2(media);
    return m.reply(formatResponse(result));
  } catch (error) {
    console.error('Error uploading file:', error);
    return m.reply(`⛩️ Terjadi kesalahan saat mengupload: ${error.message}`);
  }
}

handler.help = ['up'];
handler.tags = ['tools'];
handler.command = /^(tourl|upload|up)$/i;
handler.limit = true;

module.exports = handler;

// Function to upload media to Pomf2
async function uploadPomf2(media) {
  const formData = new FormData();
  formData.append('files[]', media, {
    filename: `uploaded_${Date.now()}.jpg`, // Use timestamp for unique filename
  });

  try {
    const response = await axios.post('https://pomf2.lain.la/upload.php', formData, {
      headers: {
        ...formData.getHeaders(),
      },
    });
    return response.data;
  } catch (error) {
    throw new Error(error?.response?.data?.message || 'Gagal mengupload file. Silakan coba lagi.');
  }
}

// Function to format the response message
function formatResponse(result) {
  const file = result.files[0];
  return `*[ Uploader ]*

*Name:* ${file.name}
*Link:* ${file.url}
*Size:* ${file.size} bytes
*Expired:* Not expired date`;
}