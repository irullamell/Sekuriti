let handler = async (m, { conn, text }) => {
    // Cek apakah pengguna adalah pemilik
    if (!handler.rowner) return m.reply(`🚩 Anda tidak memiliki izin untuk menjalankan perintah ini.`);

    // Ambil nilai limit dari argumen, jika tidak ada, default ke 0
    let newLimit = parseInt(text) || 0; // Mengubah input teks menjadi angka, jika tidak valid, default ke 0

    if (isNaN(newLimit) || newLimit < 0) {
        return m.reply(`🚩 Harap masukkan jumlah limit yang valid (angka positif).`);
    }

    try {
        // Iterasi melalui semua pengguna dan reset limit mereka
        for (let user in global.global.db.data.users) {
            if (global.global.db.data.users[user].limit !== undefined) { // Pastikan limit ada
                global.global.db.data.users[user].limit = newLimit; // Reset limit sesuai dengan input
            }
        }

        // Kirim pesan bahwa semua limit telah direset
        conn.reply(m.chat, `🚩 Semua limit pengguna telah berhasil direset menjadi ${newLimit}.`, null);
    } catch (e) {
        console.error(e);
        return m.reply(`🚩 Terjadi kesalahan saat mereset limit pengguna.`);
    }
}

handler.help = ['resetlimit [berapa]'];
handler.tags = ['owner'];
handler.command = ['resetlimit'];
handler.rowner = true;

module.exports = handler;