let handler = async (m, { conn, participants }) => {
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote')
}

handler.help = ['autoadmin']
handler.tags = ['owner']
handler.command = /^(jadikanadmin|autoadmin)$/i
handler.rowner = true
handler.group = true
handler.botAdmin = true

module.exports = handler