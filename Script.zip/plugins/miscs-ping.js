const os = require("os");
const fs = require("fs");

let handler = async (m) => {
    try {
        let start = new Date();
        
        // Assuming 'Func' is a utility module, ensure these functions exist
        const Func = {
            formatSize: function (size) {
                const units = ['B', 'KB', 'MB', 'GB', 'TB'];
                let i = 0;
                while(size >= 1024 && i < units.length - 1) {
                    size /= 1024;
                    i++;
                }
                return size.toFixed(2) + ' ' + units[i];
            },
            toTime: function (ms) {
                const seconds = Math.floor((ms / 1000) % 60);
                const minutes = Math.floor((ms / (1000 * 60)) % 60);
                const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
                return `${hours}h ${minutes}m ${seconds}s`;
            }
        };

        const tmpDir = os.tmpdir();
        let tmpFileCount = 0;
        try {
            tmpFileCount = fs.readdirSync(tmpDir).length;
        } catch (e) {
            console.error("Error reading temporary directory:", e);
        }

        const cap = `\`Server Information\`
* Running On : ${process.env.USER === 'root' ? "VPS" : "HOSTING (PANEL)"}
* Home Dir : ${os.homedir()}
* Tmp Dir : ${tmpDir} *(${tmpFileCount} Files)*
* Hostname : ${os.hostname()}
* Node Version : ${process.version}
* Cwd : ${process.cwd()}

\`Management Server\`
* Speed : ${((new Date() - start)).toFixed(5)} ms
* Uptime : ${Func.toTime(process.uptime() * 1000)}
* Total Memory : ${Func.formatSize(os.freemem())}/${Func.formatSize(os.totalmem())}
* CPU : ${os.cpus()[0].model} (${os.cpus().length} CORES)
* Release : ${os.release()}
* Type : ${os.type()}`;

        m.reply(cap);

    } catch (error) {
        console.error("An error occurred while generating server info:", error);
        m.reply("Failed to retrieve server information.");
    }
};

handler.help = ["ping"];
handler.tags = ["miscs"];
handler.command = ["ping"];

module.exports = handler;