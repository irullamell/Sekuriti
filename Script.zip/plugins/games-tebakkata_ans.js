const similarity = require('similarity');
const threshold = 0.72;

async function before(m) {
    const id = m.chat;
    
    // Check if the message is a valid answer to the game
    if (!isValidAnswer(m)) return true;

    // Initialize the game state if not already done
    this.tebakkata = this.tebakkata || {};
    if (!(id in this.tebakkata)) {
        return conn.reply(m.chat, 'Soal itu telah berakhir', m);
    }

    const questionData = this.tebakkata[id];

    // Check if the response is to the current question
    if (m.quoted.id === questionData[0].id) {
        const correctAnswer = questionData[1].jawaban.toLowerCase().trim();
        
        // Check if the answer is correct
        if (isCorrectAnswer(m.text, correctAnswer)) {
            updateUserScore(m.sender, questionData[2]);
            conn.reply(m.chat, `*Benar!*\n+${questionData[2]} XP`, m);
            clearTimeout(questionData[3]);
            delete this.tebakkata[id];
        } 
        // Check for close answers
        else if (similarity(m.text.toLowerCase(), correctAnswer) >= threshold) {
            m.reply(`*Dikit Lagi!*`);
        } 
        // Wrong answer
        else {
            m.reply(`*Salah!*`);
        }
    }
    return true;
}

// Function to validate if the answer is a valid response
function isValidAnswer(m) {
    return m.quoted && m.quoted.fromMe && m.quoted.isBaileys && m.text && /Ketik.*teka/i.test(m.quoted.text) && !/.*(hint|teka)/i.test(m.text);
}

// Function to check if the answer is correct
function isCorrectAnswer(userAnswer, correctAnswer) {
    return userAnswer.toLowerCase() === correctAnswer;
}

// Function to update user's score
function updateUserScore(userId, points) {
    global.db.data.users[userId].exp += points;
    global.db.data.users[userId].wintebakkata += 1;
}

const exp = 0;

module.exports = {
    before,
    exp
};
