let moment = require('moment-timezone')

let handler = async (m, { conn, text }) => {
    if (conn.user.jid !== global.conn.user.jid) return

    const fcon = {
        key: {
            participant: `0@s.whatsapp.net`,
            ...(m.chat ? { remoteJid: `status@broadcast` } : {})
        },
        message: {
            'contactMessage': {
                'displayName': `Power bot`,
            }
        }
    }

    // Waktu dan tanggal
    let d = new Date(new Date() + 3600000)
    let locale = 'id'
    let time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })

    // Ambil semua grup
    const getGroups = await conn.groupFetchAllParticipating()
    const groups = Object.values(getGroups)

    // Pengelompokan grup berdasarkan jumlah anggota
    const largeGroups = groups.filter(group => group.participants.length > 100)
    const mediumGroups = groups.filter(group => group.participants.length > 50 && group.participants.length <= 100)
    const smallGroups = groups.filter(group => group.participants.length <= 50)

    const grouped = [...largeGroups, ...mediumGroups, ...smallGroups]
    const totalGroups = grouped.length

    // Pesan untuk broadcast
    const pesan = m.quoted && m.quoted.text ? m.quoted.text : text
    if (!pesan) throw '• *Example :* .bcgc Hello'

    // Log untuk melacak keberhasilan pengiriman pesan
    let log = []
    let successCount = 0
    let failedCount = 0

    // Fungsi broadcast dengan retry mechanism
    const broadcastMessage = async (group, retry = 0) => {
        try {
            await conn.reply(group.id, `${pesan}`, fcon, {
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        title: `${global.namabot}`,
                        thumbnailUrl: 'https://pomf2.lain.la/f/hmx3sy3h.jpg',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            })
            log.push({ group: group.subject, status: 'Success' })
            successCount++
        } catch (error) {
            if (retry < 3) {
                await broadcastMessage(group, retry + 1) // Retry up to 3 times
            } else {
                log.push({ group: group.subject, status: 'Failed' })
                failedCount++
            }
        }
    }

    // Progress indicator
    const updateProgress = (current) => {
        const progress = ((current / totalGroups) * 100).toFixed(2)
        m.reply(`📢 Broadcast Progress: ${progress}% (${current}/${totalGroups} groups)`)
    }

    m.reply(`Starting broadcast to ${totalGroups} groups...`)

    // Broadcast ke semua grup dengan throttling
    let currentGroup = 0
    for (let group of grouped) {
        await broadcastMessage(group)
        currentGroup++

        if (currentGroup % 10 === 0) updateProgress(currentGroup) // Update progress setiap 10 grup

        // Delay untuk mencegah rate-limiting
        await delay(1000 + Math.random() * 500) // Delay acak antara 1 - 1.5 detik
    }

    // Final log hasil broadcast
    m.reply(`
🎀 Broadcast selesai!
• Berhasil: ${successCount} grup
• Gagal: ${failedCount} grup

Log Pengiriman:
${log.map(entry => `• ${entry.group}: ${entry.status}`).join('\n')}
    `)
}

// Fungsi delay untuk menunggu
const delay = time => new Promise(res => setTimeout(res, time))

// Helper untuk format waktu
function clockString(ms) {
    let h = Math.floor(ms / 3600000).toString().padStart(2, '0')
    let m = (Math.floor(ms / 60000) % 60).toString().padStart(2, '0')
    let s = (Math.floor(ms / 1000) % 60).toString().padStart(2, '0')
    return `${h}:${m}:${s}`
}

handler.help = ['bcgc-v2 *[text]*']
handler.tags = ['owner']
handler.command = /^(bcgc-v2)$/i
handler.owner = true

module.exports = handler