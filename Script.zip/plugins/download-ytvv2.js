const axios = require('axios');
const yts = require('yt-search');

const getVideoId = (url) => {
    const videoIdPattern = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/[^\/\n\s]+\/|(?:v|e(?:mbed)?)\/|[^v\r\n\s]+?\/|user\/[^\/\n\s]+|embed\/|videoseries\?list=)|(?:youtu\.)?be(?:\.com)?\/(?:watch\?v=|v\/|u\/\w\/|embed\/|watch\?v%3Dd%2026|watch\?v-|-+|watch\/|-+|v=)?)((\w|-){11}).*/;
    const match = url.match(videoIdPattern);
    if (match) {
        return match[1];
    }
    throw new Error("Link Youtube tidak valid.");
}

const formatNumber = (number) => {
    return new Intl.NumberFormat().format(number);
}

const Ytdl = {
    mp4: async (url) => {
        try {
            const videoId = getVideoId(url);
            const videoUrl = (await yts(videoId)).videos[0].url;

            const {
                data: mediaData
            } = await axios.post("https://api.cobalt.tools/api/json", {
                url: videoUrl,
                filenamePattern: "basic",
                resolution: "480p",
            }, {
                headers: {
                    Accept: "application/json",
                    origin: "https://cobalt.tools",
                    referer: "https://cobalt.tools/",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/128.0.0.0 Safari/537.36",
                }
            });

            const videoData = (await yts("https://youtu.be/" + videoId)).videos[0];
            const authorData = (await yts(videoData.author.name)).channels[0];

            return {
                status: true,
                msg: "Success Download Content!",
                title: videoData.title,
                metadata: {
                    id: videoData.videoId,
                    duration: videoData.timestamp,
                    thumbnail: videoData.image,
                    views: formatNumber(videoData.views),
                    description: videoData.description,
                },
                author: {
                    name: authorData.name,
                    url: authorData.url,
                    bio: authorData.about,
                    avatar: authorData.image,
                    subscriber: formatNumber(authorData.subCount),
                },
                url: "https://youtu.be/" + videoId,
                media: mediaData.url,
            }
        } catch (error) {
            return {
                status: false,
                msg: error.message,
                err: error,
            }
        }
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `‣ Example: ${usedPrefix + command} https://youtube.com/watch?v=HdWAVjRB0Y4`;
    
    conn.sendMessage(m.chat, {
        react: {
            text: jam,
            key: m.key
        }
    });

    const result = await Ytdl.mp4(text);

    if (result.status) {
        const caption = `*YOUTUBE DOWNLOADER*

*Judul:* ${result.title}
*Durasi:* ${result.metadata.duration}
*Views:* ${result.metadata.views}
*Deskripsi:* ${result.metadata.description}
*Author:* ${result.author.name} (${result.author.subscriber} subscriber)
*Link:* ${result.url}
`;
        await conn.sendFile(m.chat, result.media, 'video.mp4', caption, m);
    } else {
        throw result.msg;
    }
}

handler.help = ['ytmp4-v2'];
handler.tags = ['downloader'];
handler.command = ['ytmp4-v2'];
handler.limit = true;

module.exports = handler;