const similarity = require('similarity');
const threshold = 0.72;

module.exports = {
   async before(m, { conn, users, Func }) {
      let id = m.chat;
      conn.tebakgambar = conn.tebakgambar ? conn.tebakgambar : {};
      
      if (m.quoted && m.quoted.sender != conn.decodeJid(conn.user.jid)) return;
      if (m.quoted && /hint untuk bantuan/i.test(m.quoted.text)) {
         if (!(id in conn.tebakgambar) && /hint untuk bantuan/i.test(m.quoted.text)) return m.reply('Soal itu telah berakhir');
         if (m.quoted.id == conn.tebakgambar[id][0].id) {
            if (['Timeout', ''].includes(m.text)) return !0;

            let json = JSON.parse(JSON.stringify(conn.tebakgambar[id][1]));
            if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
               // Correct answer
               await m.reply(`*Benar*, *+ ${Func.formatNumber(conn.tebakgambar[id][2])} Exp*`).then(() => {
                  users.exp += conn.tebakgambar[id][2];
                  users.wintebakgambar += 1;
                  clearTimeout(conn.tebakgambar[id][3]);
                  delete conn.tebakgambar[id];
               });
            } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
               // Close answer
               m.reply(`*Dikit Lagi!*`);
            } else {
               // Incorrect answer
               m.reply(`*Salah!*`);
               users.wrongans = (users.wrongans || 0) + 1; // Increment wrong answer count
            }
         }
      }
      return true;
   }
};
