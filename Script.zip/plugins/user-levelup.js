let levelling = require('../lib/levelling');
const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');

let handler = async (m, { conn, Func }) => {
    let user = global.db.data.users[m.sender];
    let { min, xp, max } = levelling.xpRange(user.level, global.multiplier);
    let expProgress = (user.exp - min) / xp; // Progress percentage

    // Fetch user's profile picture or use default if there's an error
    let pic;
    try {
        pic = await Func.fetchBuffer(await conn.profilePictureUrl(m.sender, 'image')); // Fetch user's profile picture as buffer
    } catch (e) {
        console.log('Failed to fetch profile picture, using default image.');
        pic = await Func.fetchBuffer('./src/image/default.png'); // Fallback to default image buffer
    }

    // Define dimensions for the card
    const width = 800; // Width of the card
    const height = 450; // Height of the card
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Draw the background with a gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#1A1A2E'); // Dark gradient color
    gradient.addColorStop(1, '#16213E'); // Slightly lighter gradient color
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Draw the top bar with a rounded bottom edge
    ctx.fillStyle = '#0F3460'; // Darker top bar color
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(width, 0);
    ctx.lineTo(width, 60);
    ctx.quadraticCurveTo(width, 60, width - 20, 60); // Rounded corner
    ctx.lineTo(20, 60);
    ctx.quadraticCurveTo(0, 60, 0, 0); // Rounded corner
    ctx.fill();

    // Draw level and XP text
    ctx.fillStyle = '#FFFFFF'; // White text color
    ctx.font = 'bold 36px Arial';
    ctx.fillText(`Level: ${user.level}`, 20, 100); // Level text
    ctx.font = '24px Arial';
    ctx.fillText(`XP: ${user.exp} / ${max}`, 20, 150); // XP text

    // Draw user profile image with a border
    ctx.fillStyle = '#FFD700'; // Gold color for the profile border
    ctx.beginPath();
    ctx.arc(680, 150, 70, 0, Math.PI * 2, true); // Outer circle for the border
    ctx.fill();

    ctx.fillStyle = '#3E3E50'; // Circle background
    ctx.beginPath();
    ctx.arc(680, 150, 60, 0, Math.PI * 2, true); // Inner circle for image
    ctx.fill();

    ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
    ctx.shadowBlur = 10; // Shadow effect for profile image
    ctx.beginPath();
    ctx.arc(680, 150, 50, 0, Math.PI * 2, true); // Profile image mask
    ctx.closePath();
    ctx.clip(); // Clip the image to the circle shape

    // Load and draw profile image
    try {
        const img = await loadImage(pic); // Load profile picture from buffer
        ctx.drawImage(img, 630, 100, 100, 100); // Position and size of the image
        ctx.restore(); // Restore the clipping region
    } catch (e) {
        console.log('Failed to load profile image from buffer.');
    }

    // Draw progress bar (hotbar) for leveling
    const drawProgressBar = (x, y, width, height, progress) => {
        ctx.fillStyle = '#FFFFFF'; // White for the bar background
        ctx.fillRect(x, y, width, height); // Background of the bar

        ctx.fillStyle = '#31A2F2'; // Progress color
        ctx.fillRect(x, y, width * progress, height); // Filled part of the bar

        ctx.fillStyle = '#FFFFFF'; // White for border
        ctx.strokeStyle = '#FFFFFF'; // Border color
        ctx.lineWidth = 3;
        ctx.strokeRect(x, y, width, height); // Draw border around the bar
    };

    // Draw the progress bar at the bottom of the card
    drawProgressBar(20, 220, 740, 30, expProgress); // Progress bar dimensions

    // Draw level bar below the progress bar
    ctx.fillStyle = '#FFD700'; // Gold for level bar background
    ctx.fillRect(20, 270, 740, 20); // Background of the level bar

    ctx.fillStyle = '#31A2F2'; // Progress color for level bar
    ctx.fillRect(20, 270, (740 * user.level) / 100, 20); // Filled part of the level bar (assuming max level is 100)

    ctx.fillStyle = '#FFFFFF'; // White text color for level
    ctx.font = 'bold 20px Arial';
    ctx.fillText(`Level Progress: ${user.level}/100`, 300, 287); // Level progress text

    // Draw level up message
    if (levelling.canLevelUp(user.level, user.exp, global.multiplier)) {
        ctx.fillStyle = '#00FF00'; // Green for level up message
        ctx.font = 'bold 30px Arial';
        ctx.fillText(`🎉 Selamat! Level Up dari ${user.level} ke ${user.level + 1}! 🎉`, 20, 350); // Celebration text
    }

    // Save and send the image based on whether user can level up or not
    if (!levelling.canLevelUp(user.level, user.exp, global.multiplier)) {
        // Not enough exp card
        const buffer = canvas.toBuffer('image/png');
        const fileName = `./tmp/needexp-${m.sender}.png`;
        fs.writeFileSync(fileName, buffer);

        await conn.sendFile(m.chat, fileName, 'needexp.png', `
Level *${user.level} (${user.exp - min}/${xp})*
Kurang *${max - user.exp}* lagi!
`.trim(), m);
        return;
    }

    // Handle the case where the user levels up
    let before = user.level * 1;
    while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) user.level++;

    if (before !== user.level) {
        const buffer = canvas.toBuffer('image/png');
        const fileName = `./tmp/levelup-${m.sender}.png`;
        fs.writeFileSync(fileName, buffer);

        await conn.sendFile(m.chat, fileName, 'levelup.png', `
Selamat, anda telah naik level!
*${before}* ke *${user.level}*
gunakan *.profile* untuk mengecek
`.trim(), m);
    }
};

handler.help = ['levelup'];
handler.tags = ['user'];
handler.command = ["levelup", "level"];

module.exports = handler;