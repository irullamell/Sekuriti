const { MessageType } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, usedPrefix, args, command, Func }) => {
  // Check if arguments are provided
  if (!args || args.length < 2) {
    return m.reply(`Penggunaan yang benar:\n` +
      `1. Untuk menambahkan limit: \n` +
      `   \`${usedPrefix}+limit 6285955204711 1000\`\n` +
      `2. Untuk mengurangi limit:\n` +
      `   \`${usedPrefix}-limit 6285955204711 500\`\n` +
      `3. Untuk mengatur limit:\n` +
      `   \`${usedPrefix}setlimit 6285955204711 1500\`\n` +
      `*Pastikan nomor yang digunakan dalam format: 62xxxxxxxxxx*`);
  }

  // Mark the chat as read
  conn.chatRead(m.chat);
  
  // Send a loading reaction
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  // Extract and trim the number and points from args
  let [number, points] = args.join(' ').split(' ').map(arg => arg.trim());
  
  // Validate the phone number format
  if (!/^\d{10,15}$/.test(number)) {
    throw 'Masukkan nomor pengguna yang valid. Contoh: 6285955204711';
  }

  let mentionedJid = number + '@s.whatsapp.net';
  let users = global.db.data.users;

  // Create a new user entry if it doesn't exist
  if (!users[mentionedJid]) {
    users[mentionedJid] = { limit: 0, exp: 0, lastclaim: 0 };
  }

  // Parse and validate the points
  let pointsInt = parseInt(points);
  if (isNaN(pointsInt) || pointsInt <= 0) {
    throw `Jumlah limit harus berupa angka positif. Contoh: .${command} 6285955204711 1000`;
  }

  // Handle limit operations based on the command
  switch (command) {
    case '+limit':
      users[mentionedJid].limit += pointsInt;
      conn.reply(m.chat, `Berhasil menambahkan ${pointsInt} limit untuk nomor ${number}.`, m, {
        mentions: [mentionedJid]
      });
      break;

    case '-limit':
      if (users[mentionedJid].limit < pointsInt) {
        throw `Limit pengguna tidak cukup. Pengguna saat ini memiliki ${users[mentionedJid].limit} limit.`;
      }
      users[mentionedJid].limit -= pointsInt;
      conn.reply(m.chat, `Berhasil mengurangi ${pointsInt} limit untuk nomor ${number}. Sisa limit sekarang: ${users[mentionedJid].limit}`, m, {
        mentions: [mentionedJid]
      });
      break;

    case 'setlimit':
      users[mentionedJid].limit = pointsInt;
      conn.reply(m.chat, `Limit untuk nomor ${number} telah diatur menjadi ${pointsInt}.`, m, {
        mentions: [mentionedJid]
      });
      break;

    default:
      throw 'Perintah tidak dikenal. Silakan gunakan +limit, -limit, atau setlimit.';
  }

  // Send a success reaction
  conn.sendMessage(m.chat, {
    react: {
      text: '✅',
      key: m.key,
    }
  });
};

handler.help = ['+limit nomor jumlah', '-limit nomor jumlah', 'setlimit nomor jumlah'];
handler.tags = ['owner'];
handler.command = ["+limit", "-limit", "setlimit"]; // All limit-related commands
handler.owner = true;

module.exports = handler;