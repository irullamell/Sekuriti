const fs = require("fs");
const { exec } = require("child_process");
const cp = require("child_process");
const { promisify } = require("util");
let exec_ = promisify(exec).bind(cp);

let handler = async (m, { conn, isROwner }) => {
   try {
      let zipFileName = `Script.zip`;

      m.react('⏱️');

      // Step 1: Notifikasi pengecualian direktori tertentu
      setTimeout(() => {
         if (fs.existsSync("session")) {
            m.reply("⚠️ Direktori 'session' tidak akan ikut dibackup.");
         } else {
            m.reply("ℹ️ Direktori 'session' tidak ditemukan.");
         }
      }, 1000);

      setTimeout(() => {
         if (fs.existsSync("node_modules")) {
            m.reply("⚠️ Direktori 'node_modules' tidak akan ikut dibackup.");
         } else {
            m.reply("ℹ️ Direktori 'node_modules' tidak ditemukan.");
         }
      }, 2000);

      // Step 2: Mengeksekusi perintah ZIP dan mengecualikan direktori
      setTimeout(async () => {
         try {
            let zipCommand = `zip -r ${zipFileName} * -x "node_modules/*" "session/*" "*.zip"`;
            await exec_(zipCommand); // Menggunakan `await` agar ZIP berjalan sinkron
            m.react('📦');

            // Step 3: Mengirim file ZIP setelah selesai dibuat
            setTimeout(() => {
               if (fs.existsSync(zipFileName)) {
                  const file = fs.readFileSync(zipFileName);
                  conn.sendMessage(
                     m.chat,
                     {
                        document: file,
                        mimetype: "application/zip",
                        fileName: zipFileName,
                        caption: "✅ Backup selesai. Silakan unduh file backup di atas.",
                     },
                     { quoted: m }
                  );

                  // Step 4: Menghapus file ZIP setelah beberapa saat
                  setTimeout(() => {
                     fs.unlinkSync(zipFileName);
                     m.react('🚮');
                  }, 5000);
               } else {
                  m.reply("❌ Terjadi kesalahan. File backup tidak ditemukan.");
               }
            }, 3000);
         } catch (err) {
            m.reply("❌ Terjadi kesalahan saat membuat file ZIP.");
            console.error(err);
         }
      }, 3000);
   } catch (error) {
      m.reply("❌ Terjadi kesalahan saat melakukan backup.");
      console.error(error);
   }
};

handler.help = ["backupsc"];
handler.tags = ["owner"];
handler.command = ["backupsc"];
handler.owner = true;

module.exports = handler;