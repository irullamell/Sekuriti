module.exports = {
  run: async (m, { conn, isOwner, text, isAdmin, Func }) => {
    let who
    let reason = text.split('|')[1] ? text.split('|')[1].trim() : 'No reason provided'
    let target = text.split('|')[0] ? text.split('|')[0].trim() : text

    if (m.isGroup) {
      if (!(isAdmin || isOwner)) {
        m.reply(global.status.admin)
        throw false
      }
      if (isOwner) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : target ? target.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
      else who = m.chat
    } else {
      if (!isOwner) {
        m.reply(global.status.owner)
        throw false
      }
      who = target ? target.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
    }

    try {
      if (who.endsWith('g.us')) global.db.data.groups[who].isBanned = true
      else global.db.data.users[who].banned = true

      let chatName = await conn.getName(who) || 'this chat'
      
      // Kirim pesan ke pengguna yang dibanned
      await conn.sendMessage(who, {
        text: `You have been banned from interacting with the bot.\nReason: ${reason}.`
      })

      // Kirim pesan konfirmasi ke admin/owner
      conn.reply(m.chat, `Successfully banned! ${await conn.user.name} is inactive on chat ${chatName}. Reason: ${reason}.`, m)
    } catch (e) {
      console.log(e)
      return m.reply(Func.jsonFormat(e))
    }
  },
  help: ['banned'],
  use: 'mention or reply, | to add reason',
  tags: ['owner'],
  command: /^(banned|ban|banchat)$/i,
  owner: true
}