const fs = require('fs');
const path = require('path');
const _fs = fs.promises;

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) return m.reply(`Where is the path? Example: ${usedPrefix + command} plugins/menu.js`);
  
  let filename = text.replace(/plugin(s)\//i, '') + (/\.js$/i.test(text) ? '' : '.js');
  
  // Resolve directory path using __filename
  const __dirname = path.dirname(__filename);
  const pathFile = path.join(__dirname, filename);
  
  if (fs.existsSync(pathFile)) {
    await _fs.unlink(pathFile);  // Deleting the file
    m.reply(`*[🗑️]* Successful deletion of *${filename}*`.trim());
  } else {
    m.reply(`File ${filename} doesn't exist!`);
  }
}

handler.help = ['df'];
handler.tags = ['owner'];
handler.command = /^(df)$/i;
handler.rowner = true;

module.exports = handler;