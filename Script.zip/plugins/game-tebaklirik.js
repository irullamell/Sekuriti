module.exports = {
    run: async (m, {
        conn,
        usedPrefix,
        command,
        Func,
        users // Ensure users is included in the destructured parameters
    }) {
        // Initialize the game state for this connection
        conn.tebaklirik = conn.tebaklirik || {};
        const id = m.chat;
        const timeout = 30000; // 30 seconds
        const points = Func.randomInt(500, 1300); // Generate random points

        if (command === 'tebaklirik') {
            // Check if there is an ongoing game in the chat
            if (id in conn.tebaklirik) {
                return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebaklirik[id][0]);
            }

            // Fetch a random lyric question from the JSON file
            let res;
            try {
                res = await Func.fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json');
            } catch (error) {
                return conn.reply(m.chat, 'Error fetching data. Please try again later.', m);
            }

            const json = res[Math.floor(Math.random() * res.length)];
            const caption = generateCaption(json, timeout, usedPrefix);

            // Store the question and start the timeout
            conn.tebaklirik[id] = [
                await conn.reply(m.chat, caption, m),
                json,
                points,
                setTimeout(() => handleTimeout(conn, id, json.jawaban, users), timeout)
            ];
        } else if (command === 'teli') {
            // Provide a clue if there is an ongoing game
            if (!(id in conn.tebaklirik)) throw false;
            const clue = generateClue(conn.tebaklirik[id][1].jawaban);
            conn.reply(m.chat, '```' + clue + '```\nBalas soalnya, bukan pesan ini', conn.tebaklirik[id][0]);
        }
    },
    help: ['tebaklirik'],
    tags: ['game'],
    command: /^(tebaklirik|teli)$/i,
    group: true,
    game: true,
    limit: true
}

// Function to generate the caption for the lyric question
function generateCaption(json, timeout, usedPrefix) {
    let caption = `– *Tebak Lirik*\n\n`;
    caption += `${json.soal}\n\n`;
    caption += `Timeout : ${timeout / 1000 / 60} menit\n`; // Convert milliseconds to minutes
    caption += `Balas pesan ini untuk menjawab, kirim ${usedPrefix}teli untuk bantuan`;
    return caption;
}

// Function to handle timeout
function handleTimeout(conn, id, correctAnswer, users) {
    if (conn.tebaklirik[id]) {
        conn.reply(conn.tebaklirik[id][0].chat, `Waktu habis!\nJawabannya adalah *${correctAnswer}*`, conn.tebaklirik[id][0]);
        
        // Increment lost games count
        users.lostgame = (users.lostgame || 0) + 1; // Initialize if undefined
    }
    delete conn.tebaklirik[id]; // Clean up the game state
}

// Function to generate a clue from the correct answer
function generateClue(answer) {
    return answer.replace(/[AIUEOaiueo]/g, '_'); // Replace vowels with underscores
}
