module.exports = {
  run: async (m, { conn, Func }) => {
    let user = global.db.data.users[m.sender];

    // Show only wins
    conn.reply(
      m.chat, 
      `*⚡ Your Stats*:\n` +
      `*Susunkata Win:* [ *${Func.formatNumber(user.winsusunkata)}* ]\n` +
      `*Tebak kata Win:* [ *${Func.formatNumber(user.wintebakkata)}* ]\n` +
      `*Siapakah aku Win:* [ *${Func.formatNumber(user.winsiapakahaku)}* ]\n` +
      `*Tebak Bendera Win:* [ *${Func.formatNumber(user.wintebakbendera)}* ]\n` +
      `*Tebak gambar Win:* [ *${Func.formatNumber(user.wintebakgambar)}* ]\n` +
      `*Teka Teki Win:* [ *${Func.formatNumber(user.wintekateki)}* ]\n` +
      `*Lengkapi kalimat Win:* [ *${Func.formatNumber(user.winlengkapikalimat)}* ]\n` +
      `> Terus bermain untuk meningkatkan win game kamu`, 
      m
    );
  },
  help: ['gamestat'],
  tags: ['user'],
  command: /^(win|gamestat)$/i
}