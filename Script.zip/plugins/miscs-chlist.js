let handler = async (m, { conn, command }) => {
    if (command === "chlist") {
        try {
            let ids = Object.keys(db.data.chats).filter(id => id.endsWith("@newsletter"));
            let newsletters = await Promise.all(ids.map(async (id) => {
                try {
                    let meta = await conn.newsletterMetadata("jid", id);
                    return {
                        subject: meta.name || "Unknown",
                        id: meta.id || "Unknown",
                        role: meta.viewer_metadata?.role || "Unknown",
                        followers: meta.subscribers?.toLocaleString() || "0",
                        create: require("moment-timezone")(meta.creation_time * 1000).format("DD/MM/YYYY HH:mm:ss"),
                        picture: meta.picture ? "https://pps.whatsapp.net" + meta.picture : "N/A",
                        url: meta.invite ? `https://whatsapp.com/channel/${meta.invite}` : "N/A"
                    };
                } catch (error) {
                    console.error(`Failed to fetch metadata for ${id}:`, error);
                    return null;  // Skip any failed items
                }
            }));

            // Filter out any null entries (failed metadata fetches)
            newsletters = newsletters.filter(n => n !== null);

            let cap = `*– 乂 N E W S L E T T E R -  L I S T*\n\n${
                newsletters.map(a => 
                    Object.entries(a).map(([key, value]) => `   ◦ ${key.charAt(0).toUpperCase() + key.slice(1)} : ${value}`).join("\n")
                ).join("\n\n")
            }\n\n> Total Newsletter Chat: ${newsletters.length}`;

            m.reply(cap);
        } catch (error) {
            console.error("Error generating newsletter list:", error);
            m.reply("Failed to generate the newsletter list. Please try again later.");
        }
    }
};

handler.help = handler.command = ["chlist"];
handler.tags = ["miscs"];

module.exports = handler;