module.exports = {
  run: async (m, { conn, Func }) => {
    // Fetch all users from the database
    const users = global.db.data.users;
    const leaderboard = [];

    // Prepare the leaderboard by extracting users and their hitstats
    for (const userId in users) {
      const user = users[userId];
      if (user && user.hit) {
        leaderboard.push({
          id: userId,
          name: user.name || 'Unknown',
          hitstat: user.hit,
        });
      }
    }

    // Sort the leaderboard by hitstat in descending order
    leaderboard.sort((a, b) => b.hitstat - a.hitstat);

    // Create the leaderboard message
    let caption = `*[ HITSTAT LEADERBOARD ]*\n\n`;
    caption += `Rank | Name | Hitstat\n`;
    caption += `-----|------|--------\n`;

    // Limit the number of leaderboard entries shown
    const limit = Math.min(10, leaderboard.length);
    for (let i = 0; i < limit; i++) {
      const { name, hitstat } = leaderboard[i];
      caption += `${i + 1}    | ${name} | ${Func.formatNumber(hitstat)}\n`;
    }

    // Check if the leaderboard is empty
    if (leaderboard.length === 0) {
      caption = 'No data available for the leaderboard.';
    }

    // Send the leaderboard message
    conn.reply(m.chat, caption, m);
  },
  help: ['tophit'],
  use: '',
  tags: ['user'],
  command: /^(tophit)$/i
};