const axios = require('axios');
const cheerio = require('cheerio');

async function twitter(url) {
let obj = {
url: url,
submit: ""
};
let data = await axios.post("https://www.expertsphp.com/instagram-reels-downloader.php", new URLSearchParams(Object.entries(obj)), {
headers: {
"content-type": "application/x-www-form-urlencoded",
cookie: "_ga=GA1.2.783835709.1637038175; __gads=ID=5b4991618655cd86-22e2c7aeadce00ae:T=1637038176:RT=1637038176:S=ALNI_MaCe3McPrVVswzBEqcQlgnVZXtZ1g; _gid=GA1.2.1817576486.1639614645; _gat_gtag_UA_120752274_1=1",
origin: "https://www.expertsphp.com",
referer: "https://www.expertsphp.com/twitter-video-downloader.html",
"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
}
});
let $ = cheerio.load(data.data);
let result = [];
$("table.table > tbody > tr").each(function () {
let _quality = $(this).find("td").eq(2).find("strong").text();
let _mimetype = $(this).find("td").eq(1).find("strong").text();
let _url = $(this).find("td").eq(0).find("a[href]").attr("href");
result.push({
quality: _quality,
mimetype: _mimetype,
url: _url
});
});
return result;
}

exports.run = {
usage: ['twitter'],
hidden: ['tw'],
use: 'url twitter',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://twitter.com/akila_syafina1/status/1739769718318465429?t=LtQmZUNU2_lUkLqi91-UTQ&s=19'))
if (!m.args[0].includes('twitter.com')) return m.reply(mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
await twitter(m.args[0]).then(async (data) => {
if (data.length == 0) return m.reply('Empty data.')
for (let i of data) {
await func.delay(1000)
await mecha.sendMedia(m.chat, i.url, m, {
caption: `${i.mimetype ? '◦ Type : ' + i.mimetype : ''}${i.quality ? '\n◦ Quality : ' + i.quality : ''}`, 
expiration: m.expiration
});
}
})
},
limit: 5
}