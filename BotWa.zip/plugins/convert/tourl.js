const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

exports.run = {
  usage: ['tourl'],
  use: 'reply photo',
  category: 'convert',
  async: async (m, { func, mecha, quoted }) => {
    try {
      if (/image|video|audio|webp/.test(quoted.mime)) {
        // Download the quoted media
        let buffer = await quoted.download();

        // Check if the buffer size exceeds 5 MB
        if (buffer.length > 5 * 1024 * 1024) { // 5 MB limit
          return m.reply('Ukuran file terlalu besar! Maksimal 5 MB.');
        }

        // Validate the file type
        let fileType = await fromBuffer(buffer);
        if (!fileType || !['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'audio/mpeg'].includes(fileType.mime)) {
          return m.reply('Format file tidak diizinkan! Hanya mendukung JPG, PNG, GIF, MP4, dan MP3.');
        }

        // Determine the file extension
        let ext = fileType.ext;
        let bodyForm = new FormData();
        bodyForm.append("fileToUpload", buffer, "file." + ext);
        bodyForm.append("reqtype", "fileupload");

        // Upload to catbox.moe
        let res = await fetch("https://catbox.moe/user/api.php", {
          method: "POST",
          body: bodyForm,
        });

        // Check for successful upload response
        if (!res.ok) {
          throw new Error('Upload gagal, coba lagi nanti.');
        }

        // Get the response URL
        let url = await res.text();
        if (!url.startsWith('https://')) {
          throw new Error('URL tidak valid, coba lagi.');
        }

        mecha.reply(m.chat, '' + url, m, {
          expiration: m.expiration
        });
      } else {
        m.reply('Input media dengan benar!');
      }
    } catch (error) {
      console.error(error);
      m.reply(`Terjadi kesalahan: ${error.message}`);
    }
  },
  limit: true
}