const cooldown = 900000;

exports.run = {
  usage: ['adventure'],
  hidden: ['petualang', 'berpetualang'],
  category: 'rpg',
  async: async (m, { func, mecha, setting }) => {
    let user = global.db.users[m.sender];
    let timers = cooldown - (new Date - user.lastadventure);

    if (user.health < 80) return m.reply(`Butuh minimal *❤️ 80 Health* untuk ${m.command}!!\n\nKetik *${m.prefix}heal* untuk menambah health.\nAtau *${m.prefix}use potion* untuk menggunakan potion.`);
    if (new Date - user.lastadventure <= cooldown) return m.reply(`Kamu sudah berpetualang, mohon tunggu *${func.clockString(timers)}*`);

    user.adventurecount += 1;

    // Dynamic encounters and rewards
    const encounters = [
      { type: "finding_resources", healthLoss: ranNumb(1, 3), rewards: { money: ranNumb(500, 1000), exp: ranNumb(200, 500), wood: ranNumb(1, 5), rock: ranNumb(1, 5) }},
      { type: "monster_battle", healthLoss: ranNumb(5, 10), rewards: { money: ranNumb(1000, 2000), exp: ranNumb(500, 1000), trash: ranNumb(10, 50), common: ranNumb(0, 1) }},
      { type: "treasure_discovery", healthLoss: ranNumb(2, 5), rewards: { money: ranNumb(2000, 3000), exp: ranNumb(700, 1200), string: ranNumb(1, 3), gold: ranNumb(0, 1) }}
    ];

    // Select a random encounter
    let encounter = encounters[Math.floor(Math.random() * encounters.length)];
    let healthLost = encounter.healthLoss;
    let rewards = encounter.rewards;

    user.health -= healthLost;
    user.money += rewards.money || 0;
    user.exp += rewards.exp || 0;
    user.trash += rewards.trash || 0;
    user.rock += rewards.rock || 0;
    user.wood += rewards.wood || 0;
    user.string += rewards.string || 0;
    user.common += rewards.common || 0;
    user.gold += rewards.gold || 0;
    if (user.adventurecount % 150 == 0) user.emerald += 1;
    if (user.adventurecount % 400 == 0) user.diamond += 1;

    // Generate adventure report
    let txt = `乂  *RPG - ADVENTURE*\n\n`;
    txt += `⚔️ Encounter: *${encounter.type.replace('_', ' ').toUpperCase()}*\n`;
    txt += `❤️ health *-${healthLost}*\nAnda membawa pulang :\n`;
    if (rewards.money) txt += `*Money :* ${rewards.money}\n`;
    if (rewards.exp) txt += `*Exp :* ${rewards.exp}\n`;
    if (rewards.trash) txt += `*Trash :* ${rewards.trash}\n`;
    if (rewards.rock) txt += `*Rock :* ${rewards.rock}\n`;
    if (rewards.wood) txt += `*Wood :* ${rewards.wood}\n`;
    if (rewards.string) txt += `*String :* ${rewards.string}\n`;
    if (rewards.common) txt += `*Common :* ${rewards.common}\n`;
    if (rewards.gold) txt += `*Gold :* ${rewards.gold}\n`;
    if (user.adventurecount % 150 == 0) txt += `\nBonus adventure ${user.adventurecount} kali\n*Emerald :* 1`;
    if (user.adventurecount % 400 == 0) txt += `\nBonus adventure ${user.adventurecount} kali\n*Diamond :* 1`;

    m.reply('_Sedang berpetualang..._');
    user.lastadventure = new Date * 1;

    setTimeout(() => {
      mecha.reply(m.chat, txt, m);
    }, setting.gamewaktu * 1000);
  },
  register: true,
  limit: true
};

// Random number generator
function ranNumb(min, max = null) {
  if (max !== null) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  } else {
    return Math.floor(Math.random() * min) + 1;
  }
}