const { G4F } = require("g4f");
const g4f = new G4F();

exports.run = {
    usage: ['gpt4'],
    hidden: ['g4f'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha }) => {
        // Memastikan bahwa ada teks yang masuk untuk diproses.
        if (!m.text) return m.reply(func.example(m.cmd, 'apakah kamu gpt4?'));

        // Mengirim reaksi untuk memberi tahu bahwa proses sedang berlangsung.
        mecha.sendReact(m.chat, '🕒', m.key);

        try {
            const options = [{ model: "gpt-4" }];
            const systemMessage = `Kamu adalah AI yang sangat berguna.`;
            const messages = [
                { role: "system", content: systemMessage },
                { role: "user", content: m.text },
            ];

            // Mendapatkan jawaban dari model AI.
            let response = await g4f.chatCompletion(messages, options);
            
            // Pembersihan response untuk memastikan format yang baik.
            response = response.replace(/\\n/g, '\n')
                               .replace(/\\/g, '')
                               .replace(/\*\*/g, '*')
                               .replace(/###/g, '>').trim();

            // Mengirim balasan ke pengguna.
            mecha.reply(m.chat, response, m, {
                expiration: m.expiration
            });
        } catch (error) {
            console.error(error);
            mecha.reply(m.chat, `Terjadi kesalahan: ${String(error)}`, m);
        }
    },
    limit: true
}
