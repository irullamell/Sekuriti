exports.run = {
  usage: ['welcome', 'left', 'detect', 'antiporn', 'antitoxic', 'antilink', 'antivirtex', 'antibot', 'antiluar', 'antiviewonce', 'antihidetag', 'antidelete', 'antiedited', 'automatically'],
  use: 'on / off',
  category: 'admin tools',
  async: async (m, { func, mecha, groups }) => {
    let setting = global.db.groups[m.chat];
    
    // Periksa apakah bot memiliki izin admin untuk fitur-fitur tertentu
    if (!m.isBotAdmin && /antiporn|antitoxic|antilink|antivirtex|antibot|antihidetag|automatically/.test(m.command)) 
      return m.reply(global.mess.botAdmin);
    
    // Jika argumen tidak diberikan
    if (!m.args || !m.args[0]) {
      return m.reply(
        `*Status saat ini*: ${setting[m.command] ? 'aktif' : 'tidak aktif'}\n\n` +
        `Fitur ini memungkinkan Anda untuk mengaktifkan atau menonaktifkan *${func.ucword(m.command)}* dalam grup. Berikut ini adalah penjelasan lengkap cara penggunaan dan dampaknya.\n\n` +
        
        `*Cara Penggunaan Umum:*\n` +
        `1. Ketik *${m.cmd} on* untuk mengaktifkan fitur atau *${m.cmd} off* untuk menonaktifkannya.\n` +
        `2. Contoh: *${func.example(m.cmd, 'on')}* akan mengaktifkan fitur ${func.ucword(m.command)}.\n\n` +

        `*Keterangan Fitur:*\n` +
        `   • *Welcome*: Mengirimkan pesan selamat datang otomatis setiap kali anggota baru bergabung ke grup. Anda bisa menyesuaikan pesan ini untuk menyambut anggota baru dengan instruksi grup atau informasi penting.\n\n` +

        `   • *Left*: Mengirimkan pemberitahuan otomatis setiap kali anggota meninggalkan grup, sehingga anggota lainnya mengetahui siapa yang keluar.\n\n` +

        `   • *Detect*: Mengidentifikasi aktivitas yang mencurigakan atau tidak sah di dalam grup. Fitur ini sangat penting untuk grup dengan banyak anggota yang aktif.\n\n` +

        `   • *Antiporn*: Memblokir konten eksplisit secara otomatis. Fitur ini penting untuk menjaga grup tetap aman dan bersih dari konten dewasa.\n\n` +

        `   • *Antitoxic*: Mencegah kata-kata kasar atau bahasa yang tidak pantas di dalam grup. Fitur ini membantu menjaga lingkungan grup tetap positif dan ramah.\n\n` +

        `   • *Antilink*: Memblokir tautan eksternal yang tidak diizinkan. Ini bisa digunakan untuk mencegah anggota membagikan tautan yang mengganggu atau tidak relevan.\n\n` +

        `   • *Antivirtex*: Menghentikan spam teks kompleks atau karakter yang berlebihan yang bisa membuat aplikasi WhatsApp anggota lainnya lag atau crash.\n\n` +

        `   • *Antibot*: Mencegah bot tidak sah bergabung ke grup. Fitur ini mengamankan grup dari bot yang tidak diizinkan atau spam otomatis.\n\n` +

        `   • *Antiluar*: Membatasi pesan dari nomor yang tidak berasal dari wilayah atau negara tertentu, berguna untuk grup lokal yang ingin menjaga keanggotaan tetap dalam wilayah yang ditentukan.\n\n` +

        `   • *Antiviewonce*: Mengubah pesan “view-once” menjadi pesan biasa yang bisa dilihat berulang kali, untuk memastikan semua anggota bisa memeriksa konten yang penting lebih dari sekali.\n\n` +

        `   • *Antihidetag*: Memungkinkan Anda mendeteksi anggota yang menyembunyikan tag atau mention, sehingga tidak ada anggota yang terlewat saat penting untuk dihubungi.\n\n` +

        `   • *Antidelete*: Mencegah anggota menghapus pesan mereka. Pesan yang dihapus tetap bisa dilihat oleh admin, sehingga riwayat percakapan tetap transparan.\n\n` +

        `   • *Antiedited*: Mengirim notifikasi jika ada pesan yang diedit, agar semua anggota tetap mengetahui konteks percakapan yang diubah.\n\n` +

        `   • *Automatically*: Mengaktifkan fitur moderasi otomatis di dalam grup. Fitur ini dapat menggabungkan beberapa pengaturan otomatis seperti deteksi spam, filter kata, dan sebagainya untuk menjaga grup tetap aman dan terkendali.\n\n` +

        `*Petunjuk Tambahan:*\n` +
        `Jika Anda membutuhkan bantuan lebih lanjut, ketik *${func.example(m.cmd, 'on / off')}* untuk panduan cepat tentang cara penggunaan.`
      );
    }

    let option = m.args[0].toLowerCase();
    let optionList = ['on', 'off'];
    
    // Validasi pilihan
    if (!optionList.includes(option)) 
      return m.reply(`${func.example(m.cmd, 'on / off')}`);
    
    let status = option === 'on';
    
    // Cek jika sudah diaktifkan/nonaktifkan sebelumnya
    if (setting[m.command] == status) 
      return m.reply(`${func.ucword(m.command)} telah ${option === 'on' ? 'diaktifkan' : 'dinonaktifkan'} sebelumnya.`);
    
    // Update pengaturan dan kirim konfirmasi
    setting[m.command] = status;
    mecha.reply(m.chat, `${func.ucword(m.command)} telah ${option === 'on' ? 'diaktifkan' : 'dinonaktifkan'} dengan sukses.`, m);
  },
  admin: true,
  group: true
}