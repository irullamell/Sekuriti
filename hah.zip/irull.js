const { spawn } = require('child_process');
const http = require('http');

// Fungsi untuk menjalankan perintah startup
function runCommand(commandString) {
  const [command, ...args] = commandString.split(' ');
  spawn(command, args, {
    stdio: ['inherit', 'inherit', 'inherit', 'ipc']
  });
}

// Variabel yang dapat dengan mudah diedit
const startupCommand = 'npm start';  // Ubah command sesuai kebutuhan

// Menjalankan perintah startup
runCommand(startupCommand);

// Membuat server web sederhana
const port = 3000;
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Server is running and command is executed\n');
});

// Menjalankan server pada port yang ditentukan
server.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
