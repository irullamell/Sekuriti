const path = require('path');
const fs = require('fs');

exports.run = {
    usage: ['clearsession'],
    hidden: ['csession'],
    category: 'owner',
    async: async (m, { func, mecha }) => {
        let sessions = 'session';
        
        fs.readdir(sessions, (err, files) => {
            if (err) {
                return m.reply(`Terjadi kesalahan saat membaca folder sesi: ${err.message}`);
            }

            if (files.length === 1 && files[0] === 'creds.json') {
                return m.reply(`Tidak ada file sesi lain yang ditemukan untuk dihapus.`);
            }
            
            let deletedFiles = [];
            let skippedFiles = [];
            
            for (const file of files) {
                if (file !== 'creds.json') {
                    fs.unlink(path.join(sessions, file), err => {
                        if (!err) deletedFiles.push(file);
                    });
                } else {
                    skippedFiles.push(file);
                }
            }

            setTimeout(() => {
                let message = `Berhasil menghapus ${deletedFiles.length} file sesi.`;
                
                if (deletedFiles.length > 0) {
                    message += `\nFile yang dihapus: ${deletedFiles.join(', ')}.`;
                }
                
                if (skippedFiles.length > 0) {
                    message += `\nFile yang dilewati: ${skippedFiles.join(', ')} (tidak dihapus).`;
                }

                m.reply(message);
            }, 500); 
        });
    },
    devs: true
}
