const axios = require('axios');

class YouTubeDownloader {
/**
 * Mengunduh video dari YouTube dalam format MP4 atau MP3.
 * @param {string} url - URL video YouTube yang valid.
 * @param {string} downtype - Tipe unduhan: 'mp4' atau 'mp3'.
 * @param {string} vquality - Kualitas video atau audio:
 *  - Untuk 'mp4': '144', '240', '360', '720', '1080'
 *  - Untuk 'mp3': '128', '360'
 * @returns {Promise<string>} - URL unduhan dari API.
 */
static async downloadVideo(url, downtype, vquality) {
const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:shorts\/|watch\?v=|music\?v=|embed\/|v\/|.+\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
const match = url.match(regex);

if (!match) {
throw new Error('URL tidak valid. Silakan masukkan URL YouTube yang benar.');
}

const videoId = match[1];
const data = new URLSearchParams({ videoid: videoId, downtype, vquality });

try {
const response = await axios.post('https://api-cdn.saveservall.xyz/ajax-v2.php', data, {
headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
});
return response.data.url;
} catch (error) {
throw new Error('Terjadi kesalahan: ' + error.message);
}
}

/**
 * Mengambil link unduhan untuk kedua format MP4 dan MP3.
 * @param {string} url - URL video YouTube yang valid.
 * @param {Object} qualities - Kualitas unduhan untuk masing-masing format.
 * @param {string} qualities.mp4 - Kualitas untuk MP4.
 * @param {string} qualities.mp3 - Kualitas untuk MP3.
 * @returns {Promise<Object>} - Objek berisi URL unduhan MP4 dan MP3.
 */
static async download(url, { mp4 = '360', mp3 = '128' } = {}) {
try {
const mp4Link = await YouTubeDownloader.downloadVideo(url, 'mp4', mp4);
const mp3Link = await YouTubeDownloader.downloadVideo(url, 'mp3', mp3);
return { mp4: mp4Link, mp3: mp3Link };
} catch (error) {
throw new Error(error.message);
}
}

/**
 * Mencari video YouTube berdasarkan kata kunci.
 * @param {string} query - Kata kunci pencarian.
 * @returns {Promise<Object>} - Hasil pencarian dari API.
 */
static async search(query) {
const url = `https://api.flvto.top/@api/search/YouTube/${encodeURIComponent(query)}`;

try {
const response = await axios.get(url, {
headers: {
'Accept-Encoding': 'gzip, deflate, br',
'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
'Cache-Control': 'no-cache',
'Origin': 'https://keepvid.online',
'Referer': 'https://keepvid.online/',
'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}
});

return response.data.items.map(item => ({
...item,
url: `https://www.youtube.com/watch?v=${item.id}`
}));
} catch (error) {
throw new Error('Gagal mengambil hasil pencarian: ' + error.message);
}
}
}

async function downloadImage(url) {
try {
const response = await axios.get(url, { responseType: 'arraybuffer' });
return Buffer.from(response.data, 'binary');
} catch (error) {
return null;
}
}

exports.run = {
usage: ['play'],
use: 'judul lagu',
category: 'downloader',
async: async (m, { func, mecha }) => {
mecha.play = mecha.play ? mecha.play : {};
if (!m.text) return m.reply(func.example(m.cmd, 'melukis senja'));
mecha.sendReact(m.chat, '🕒', m.key);
try {
let searchResults = await YouTubeDownloader.search(m.text)
let data = searchResults[0];
if (!data) {
mecha.sendReact(m.chat, '❌', m.key);
return m.reply('Video/Audio tidak ditemukan.');
}
let durationInSeconds = data.duration.split(':').reduce((acc, time) => (60 * acc) + +time);
if (durationInSeconds >= 3600) {
mecha.sendReact(m.chat, '❌', m.key);
return m.reply('Video is longer than 1 hour!');
} else {
let caption = `∘ ID : ${data.id}`;
caption += `\n∘ Title : ${data.title}`;
caption += `\n∘ Duration : ${data.duration}`;
caption += `\n∘ Views : ${data.viewCount}`;
caption += `\n∘ Upload : ${data.publishedAt}`;
caption += `\n∘ Author : ${data.channelTitle}`;
caption += `\n∘ Video URL : ${data.url}`;
caption += `\n\n_reply with number *1* to get audio_`;
caption += `\n_reply with number *2* to get video_`;
caption += `\n_reply with number *3* to get document_`;
const thumbnailBuffer = await downloadImage(data.thumbMedium);
const result = await YouTubeDownloader.download(data.url, {
mp4: '360',
mp3: '128'
})
mecha.play[m.sender] = {
data: {
url: data.url,
thumbnail: thumbnailBuffer,
duration: data.duration,
title: data.title,
audio: result.mp3,
video: result.mp4
},
audio: true,
video: true,
document: true,
timeout: setTimeout(function () {
delete mecha.play[m.sender];
}, 1000 * 60 * 10)
};
let messageId = 'MECHA' + func.makeid(22).toUpperCase() + 'PLAY';
await mecha.relayMessage(m.chat, {
extendedTextMessage: {
text: caption,
contextInfo: {
externalAdReply: {
title: data.title,
mediaType: 1,
previewType: 0,
renderLargerThumbnail: true,
thumbnail: thumbnailBuffer,
sourceUrl: data.url
}
},
mentions: [m.sender]
}
}, { quoted: m, ephemeralExpiration: m.expiration, messageId: messageId });
mecha.sendReact(m.chat, '✅', m.key);
}
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key);
}
},
main: async (m, { func, mecha }) => {
mecha.play = mecha.play ? mecha.play : {};
if (mecha.play[m.sender] && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('PLAY') && !m.isPrefix) {
if (!isNaN(m.budy) && func.somematch(['1', '2', '3'], m.budy)) {
mecha.sendReact(m.chat, '🕒', m.key);
let result = mecha.play[m.sender];
let typefile = /1/.test(m.budy) ? 'audio' : /2/.test(m.budy) ? 'video' : 'document';
let ext = /1/.test(m.budy) ? '.mp3' : /2/.test(m.budy) ? '.mp4' : '.mp3';
let mimetype = /1/.test(m.budy) ? 'audio/mpeg' : /2/.test(m.budy) ? 'video/mp4' : 'audio/mpeg';
try {
await mecha.sendMessage(m.chat, {
[typefile]: {
url: result.data[typefile === 'audio' ? 'audio' : 'video']
},
caption: result.data.title,
mimetype: mimetype,
fileName: result.data.title + ext,
contextInfo: {
externalAdReply: {
title: result.data.title,
body: `${result.data.duration}`,
thumbnail: result.data.thumbnail,
mediaType: 2,
mediaUrl: result.data.url,
sourceUrl: result.data.url
}
}
}, { quoted: m, ephemeralExpiration: m.expiration }).then(_ => {
result[typefile] = false;
if (!result.audio && !result.video && !result.document) delete mecha.play[m.sender];
});
mecha.sendReact(m.chat, '✅', m.key);
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key);
mecha.reply(m.chat, String(error), m, {
expiration: m.expiration
})
}
}
}
},
restrict: true,
limit: 3
}