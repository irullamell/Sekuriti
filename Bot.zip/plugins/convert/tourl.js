const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

exports.run = {
usage: ['tourl'],
use: 'reply photo',
category: 'convert',
async: async (m, { func, mecha, quoted }) => {
if (/image|video|audio|webp/.test(quoted.mime)) {
/**
 * Upload image to catbox.moe
 * Supported mimetype:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * - `image/gif`
 * @param {Buffer} buffer Image Buffer
 */
let buffer = await quoted.download()
let { ext } = await fromBuffer(buffer);
let bodyForm = new FormData();
bodyForm.append("fileToUpload", buffer, "file." + ext);
bodyForm.append("reqtype", "fileupload");

let res = await fetch("https://catbox.moe/user/api.php", {
method: "POST",
body: bodyForm,
});

let url = await res.text();
mecha.reply(m.chat, '' + url, m, {
expiration: m.expiration
})
} else m.reply('Input media dengan benar!')
},
limit: true
}